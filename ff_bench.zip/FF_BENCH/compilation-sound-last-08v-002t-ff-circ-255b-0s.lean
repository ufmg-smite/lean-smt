import Smt
import Smt.ZMod
import Mathlib.Data.ZMod.Basic
set_option maxRecDepth 2000000000000000000000

syntax "smt_unsat" : tactic

macro_rules
  | `(tactic| smt_unsat) => `(tactic| first | smt; trace "unsat")

abbrev my_prime := 52435875175126190479447740508185965837690552500527637822603658699938581184513

theorem compilation_sound_last_08v_002t_ff_circ_255b_0s [Fact my_prime.Prime]
  (e : Bool) (d : Bool) (h : Bool) (g : Bool) (f : Bool) (c : Bool) (b : Bool) (a : Bool) (return_n5 : ZMod my_prime) (d_n3 : ZMod my_prime) (h_n6 : ZMod my_prime) (mul_n9 : ZMod my_prime) (e_n2 : ZMod my_prime) (a_n8 : ZMod my_prime) (f_n1 : ZMod my_prime) (c_n4 : ZMod my_prime) (g_n7 : ZMod my_prime) (b_n0 : ZMod my_prime) (is_zero_inv_n10 : ZMod my_prime) :
  (!((let let0 := e; (let let1 := d; (let let2 := (decide ((let1) = (let0))); (let let3 := h; (let let4 := g; (let let5 := f; (let let6 := c; (let let7 := b; (let let8 := a; (let let9 := ((((((let8 && let7) && let6) && let5) && let4) && let3) && let2); (let let10 := return_n5; (let let11 := (1 : ZMod my_prime); (let let12 := (decide ((let11) = (let10))); (let let13 := (decide ((let12) = (let9))); (let let14 := (0 : ZMod my_prime); (let let15 := (decide ((let14) = (let10))); (let let16 := (let12 || let15); (let let17 := (let16 && let13); (let let18 := (52435875175126190479447740508185965837690552500527637822603658699938581184512 : ZMod my_prime); (let let19 := (let10 * let18); (let let20 := (let19 + let11); (let let21 := (6 : ZMod my_prime); (let let22 := d_n3; (let let23 := h_n6; (let let24 := (let23 * let18); (let let25 := mul_n9; (let let26 := (let25 * let18); (let let27 := e_n2; (let let28 := a_n8; (let let29 := (let28 * let18); (let let30 := f_n1; (let let31 := (let30 * let18); (let let32 := c_n4; (let let33 := (let32 * let18); (let let34 := g_n7; (let let35 := (let34 * let18); (let let36 := b_n0; (let let37 := (let36 * let18); (let let38 := (((((((((let37 + let35) + let33) + let31) + let29) + let27) + let26) + let24) + let22) + let21); (let let39 := is_zero_inv_n10; (let let40 := (let39 * let38); (let let41 := (decide ((let40) = (let20))); (let let42 := (2 : ZMod my_prime); (let let43 := (let22 * let42); (let let44 := (let43 * let27); (let let45 := (decide ((let44) = (let25))); (let let46 := (let45 && let41); (let let47 := (if (let0) then let11 else let14); (let let48 := (decide ((let27) = (let47))); (let let49 := (if (let5) then let11 else let14); (let let50 := (decide ((let30) = (let49))); (let let51 := (if (let6) then let11 else let14); (let let52 := (decide ((let32) = (let51))); (let let53 := (if (let8) then let11 else let14); (let let54 := (decide ((let28) = (let53))); (let let55 := (if (let3) then let11 else let14); (let let56 := (decide ((let23) = (let55))); (let let57 := (if (let1) then let11 else let14); (let let58 := (decide ((let22) = (let57))); (let let59 := (if (let4) then let11 else let14); (let let60 := (decide ((let34) = (let59))); (let let61 := (if (let7) then let11 else let14); (let let62 := (decide ((let36) = (let61))); (let let63 := (((((((let62 && let60) && let58) && let56) && let54) && let52) && let50) && let48); (let let64 := (let63 && let46); (let let65 := (!(let64) || let17); (let let66 := !(let65); let66))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) = true := by
  unfold my_prime at *
  smt_unsat
