import Smt
import Smt.ZMod
import Mathlib.Data.ZMod.Basic
set_option maxRecDepth 2000000000000000000000

syntax "smt_unsat" : tactic

macro_rules
  | `(tactic| smt_unsat) => `(tactic| first | smt; trace "unsat")

abbrev my_prime := 37

theorem compilation_deterministic_random_02v_004t_ff_zokcirc_6b_0s [Fact my_prime.Prime]
  (mul_n6_alt : ZMod my_prime) (a_n2_alt : ZMod my_prime) (return_n0_alt : ZMod my_prime) (mul_n5_alt : ZMod my_prime) (mul_n4_alt : ZMod my_prime) (b_n1_alt : ZMod my_prime) (mul_n3_alt : ZMod my_prime) (mul_n6 : ZMod my_prime) (a_n2 : ZMod my_prime) (return_n0 : ZMod my_prime) (mul_n5 : ZMod my_prime) (mul_n4 : ZMod my_prime) (b_n1 : ZMod my_prime) (mul_n3 : ZMod my_prime) :
  (!((let let0 := mul_n6_alt; (let let1 := a_n2_alt; (let let2 := (36 : ZMod my_prime); (let let3 := return_n0_alt; (let let4 := (let3 * let2); (let let5 := ((let4 + let1) + let0); (let let6 := (2 : ZMod my_prime); (let let7 := (let0 * let6); (let let8 := (let7 * let1); (let let9 := (decide ((let8) = (let5))); (let let10 := mul_n5_alt; (let let11 := (let10 * let1); (let let12 := (decide ((let11) = (let0))); (let let13 := mul_n4_alt; (let let14 := b_n1_alt; (let let15 := mul_n3_alt; (let let16 := (let15 * let14); (let let17 := (decide ((let16) = (let13))); (let let18 := (let14 * let1); (let let19 := (decide ((let18) = (let15))); (let let20 := (((let19 && let17) && let12) && let9); (let let21 := mul_n6; (let let22 := a_n2; (let let23 := return_n0; (let let24 := (let23 * let2); (let let25 := ((let24 + let22) + let21); (let let26 := (let21 * let6); (let let27 := (let26 * let22); (let let28 := (decide ((let27) = (let25))); (let let29 := mul_n5; (let let30 := (let29 * let22); (let let31 := (decide ((let30) = (let21))); (let let32 := mul_n4; (let let33 := b_n1; (let let34 := mul_n3; (let let35 := (let34 * let33); (let let36 := (decide ((let35) = (let32))); (let let37 := (let33 * let22); (let let38 := (decide ((let37) = (let34))); (let let39 := (((let38 && let36) && let31) && let28); (let let40 := (decide ((let23) = (let3))); (let let41 := !(let40); (let let42 := (decide ((let33) = (let14))); (let let43 := (decide ((let22) = (let1))); (let let44 := (let43 && let42); (let let45 := (((let44 && let41) && let39) && let20); let45)))))))))))))))))))))))))))))))))))))))))))))))) = true := by
  unfold my_prime at *
  smt_unsat
