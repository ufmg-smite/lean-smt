import Smt
import Smt.ZMod
import Mathlib.Data.ZMod.Basic

abbrev k := 52435875175126190479447740508185965837690552500527637822603658699938581184513

theorem compilation_sound_last_02v_002t_ff_zokref_255b_0s [Fact k.Prime]
  (out : ZMod k) (_3 : ZMod k) (_0 : ZMod k) (_1 : ZMod k) :
  (let let0 := a; (let let1 := (¬ (let0)); (let let2 := b; (let let3 := (let2 ∧ let1); (let let4 := out; (let let5 := (1 : ZMod k); (let let6 := ((let5) = (let4)); (let let7 := ((let6) = (let3)); (let let8 := (0 : ZMod k); (let let9 := ((let8) = (let4)); (let let10 := (let6 ∨ let9); (let let11 := (let10 ∧ let7); (let let12 := _3; (let let13 := (52435875175126190479447740508185965837690552500527637822603658699938581184512 : ZMod k); (let let14 := _0; (let let15 := (let14 * let13); (let let16 := (let15 + let5); (let let17 := _1; (let let18 := (let17 * let16); (let let19 := ((let18) = (let12)); (let let20 := (let17 * let17); (let let21 := ((let20) = (let17)); (let let22 := (let14 * let14); (let let23 := ((let22) = (let14)); (let let24 := ((let23 ∧ let21) ∧ let19); (let let25 := (if let2 then let5 else let8); (let let26 := ((let17) = (let25)); (let let27 := (if let0 then let5 else let8); (let let28 := ((let14) = (let27)); (let let29 := (let28 ∧ let26); (let let30 := (let29 ∧ let24); (let let31 := ((let30) → (let11)); (let let32 := (¬ (let31)); let32))))))))))))))))))))))))))))))))) := by
  unfold k at *
  smt
