import Smt
import Smt.ZMod
import Mathlib.Data.ZMod.Basic
set_option maxRecDepth 2000000000000000000000

syntax "smt_unsat" : tactic

macro_rules
  | `(tactic| smt_unsat) => `(tactic| first | smt; trace "unsat")

abbrev my_prime := 52435875175126190479447740508185965837690552500527637822603658699938581184513

theorem compilation_deterministic_last_04v_002t_ff_zokref_255b_0s [Fact my_prime.Prime]
  (_6_alt : ZMod my_prime) (_5_alt : ZMod my_prime) (_3_alt : ZMod my_prime) (_4_alt : ZMod my_prime) (_2_alt : ZMod my_prime) (_1_alt : ZMod my_prime) (_0_alt : ZMod my_prime) (_6 : ZMod my_prime) (_5 : ZMod my_prime) (_3 : ZMod my_prime) (_4 : ZMod my_prime) (_2 : ZMod my_prime) (_1 : ZMod my_prime) (_0 : ZMod my_prime) (out_alt : ZMod my_prime) (out : ZMod my_prime) :
  (!((let let0 := (52435875175126190479447740508185965837690552500527637822603658699938581184512 : ZMod my_prime); (let let1 := _6_alt; (let let2 := (let1 * let0); (let let3 := _5_alt; (let let4 := _3_alt; (let let5 := ((let4 + let3) + let2); (let let6 := (let3 * let4); (let let7 := (decide ((let6) = (let5))); (let let8 := (let3 * let0); (let let9 := _4_alt; (let let10 := _2_alt; (let let11 := ((let10 + let9) + let8); (let let12 := (let9 * let10); (let let13 := (decide ((let12) = (let11))); (let let14 := (let9 * let0); (let let15 := _1_alt; (let let16 := _0_alt; (let let17 := ((let16 + let15) + let14); (let let18 := (let16 * let15); (let let19 := (decide ((let18) = (let17))); (let let20 := (let4 * let4); (let let21 := (decide ((let20) = (let4))); (let let22 := (let10 * let10); (let let23 := (decide ((let22) = (let10))); (let let24 := (let15 * let15); (let let25 := (decide ((let24) = (let15))); (let let26 := (let16 * let16); (let let27 := (decide ((let26) = (let16))); (let let28 := ((((((let27 && let25) && let23) && let21) && let19) && let13) && let7); (let let29 := _6; (let let30 := (let29 * let0); (let let31 := _5; (let let32 := _3; (let let33 := ((let32 + let31) + let30); (let let34 := (let31 * let32); (let let35 := (decide ((let34) = (let33))); (let let36 := (let31 * let0); (let let37 := _4; (let let38 := _2; (let let39 := ((let38 + let37) + let36); (let let40 := (let37 * let38); (let let41 := (decide ((let40) = (let39))); (let let42 := (let37 * let0); (let let43 := _1; (let let44 := _0; (let let45 := ((let44 + let43) + let42); (let let46 := (let44 * let43); (let let47 := (decide ((let46) = (let45))); (let let48 := (let32 * let32); (let let49 := (decide ((let48) = (let32))); (let let50 := (let38 * let38); (let let51 := (decide ((let50) = (let38))); (let let52 := (let43 * let43); (let let53 := (decide ((let52) = (let43))); (let let54 := (let44 * let44); (let let55 := (decide ((let54) = (let44))); (let let56 := ((((((let55 && let53) && let51) && let49) && let47) && let41) && let35); (let let57 := out_alt; (let let58 := out; (let let59 := (decide ((let58) = (let57))); (let let60 := !(let59); (let let61 := (decide ((let43) = (let15))); (let let62 := (decide ((let44) = (let16))); (let let63 := (decide ((let38) = (let10))); (let let64 := (decide ((let32) = (let4))); (let let65 := (((let64 && let63) && let62) && let61); (let let66 := (((let65 && let60) && let56) && let28); let66))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) = true := by
  unfold my_prime at *
  smt_unsat
