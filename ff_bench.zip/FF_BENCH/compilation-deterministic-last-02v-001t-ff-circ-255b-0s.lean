import Smt
import Smt.ZMod
import Mathlib.Data.ZMod.Basic

abbrev k := 52435875175126190479447740508185965837690552500527637822603658699938581184513

theorem compilation_deterministic_last_02v_001t_ff_circ_255b_0s [Fact k.Prime]
  (return_n0_alt : ZMod k) (b_n1_alt : ZMod k) (a_n2_alt : ZMod k) (return_n0 : ZMod k) (b_n1 : ZMod k) (a_n2 : ZMod k) :
  (let let0 := (1 : ZMod k); (let let1 := (52435875175126190479447740508185965837690552500527637822603658699938581184512 : ZMod k); (let let2 := return_n0_alt; (let let3 := (let2 * let1); (let let4 := (let3 + let0); (let let5 := b_n1_alt; (let let6 := (let5 * let1); (let let7 := (let6 + let0); (let let8 := a_n2_alt; (let let9 := (let8 * let1); (let let10 := (let9 + let0); (let let11 := (let10 * let7); (let let12 := ((let11) = (let4)); (let let13 := return_n0; (let let14 := (let13 * let1); (let let15 := (let14 + let0); (let let16 := b_n1; (let let17 := (let16 * let1); (let let18 := (let17 + let0); (let let19 := a_n2; (let let20 := (let19 * let1); (let let21 := (let20 + let0); (let let22 := (let21 * let18); (let let23 := ((let22) = (let15)); (let let24 := ((let13) = (let2)); (let let25 := (¬ (let24)); (let let26 := ((let16) = (let5)); (let let27 := ((let19) = (let8)); (let let28 := (let27 ∧ let26); (let let29 := (((let28 ∧ let25) ∧ let23) ∧ let12); let29)))))))))))))))))))))))))))))) := by
  unfold k at *
  smt
