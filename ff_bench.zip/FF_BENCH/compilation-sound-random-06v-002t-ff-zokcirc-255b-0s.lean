import Smt
import Smt.ZMod
import Mathlib.Data.ZMod.Basic
set_option maxRecDepth 2000000000000000000000

syntax "smt_unsat" : tactic

macro_rules
  | `(tactic| smt_unsat) => `(tactic| first | smt; trace "unsat")

abbrev my_prime := 52435875175126190479447740508185965837690552500527637822603658699938581184513

theorem compilation_sound_random_06v_002t_ff_zokcirc_255b_0s [Fact my_prime.Prime]
  (c : Bool) (b : Bool) (d : Bool) (f : Bool) (e : Bool) (a : Bool) (return_n3 : ZMod my_prime) (mul_n7 : ZMod my_prime) (c_n2 : ZMod my_prime) (mul_n9 : ZMod my_prime) (f_n5 : ZMod my_prime) (mul_n8 : ZMod my_prime) (b_n4 : ZMod my_prime) (d_n1 : ZMod my_prime) (e_n0 : ZMod my_prime) (a_n6 : ZMod my_prime) :
  (!((let let0 := c; (let let1 := b; (let let2 := d; (let let3 := (if (let2) then let1 else let0); (let let4 := f; (let let5 := e; (let let6 := a; (let let7 := (((let6 || let5) || let4) || let3); (let let8 := return_n3; (let let9 := (1 : ZMod my_prime); (let let10 := (decide ((let9) = (let8))); (let let11 := (decide ((let10) = (let7))); (let let12 := (0 : ZMod my_prime); (let let13 := (decide ((let12) = (let8))); (let let14 := (let10 || let13); (let let15 := (let14 && let11); (let let16 := (52435875175126190479447740508185965837690552500527637822603658699938581184512 : ZMod my_prime); (let let17 := (let8 * let16); (let let18 := (let17 + let9); (let let19 := mul_n7; (let let20 := (let19 * let16); (let let21 := c_n2; (let let22 := (let21 * let16); (let let23 := ((let22 + let20) + let9); (let let24 := mul_n9; (let let25 := (let24 * let23); (let let26 := (decide ((let25) = (let18))); (let let27 := f_n5; (let let28 := (let27 * let16); (let let29 := (let28 + let9); (let let30 := mul_n8; (let let31 := (let30 * let29); (let let32 := (decide ((let31) = (let24))); (let let33 := b_n4; (let let34 := (let33 + let22); (let let35 := d_n1; (let let36 := (let35 * let34); (let let37 := (decide ((let36) = (let19))); (let let38 := ((let37 && let32) && let26); (let let39 := (if (let2) then let9 else let12); (let let40 := (decide ((let35) = (let39))); (let let41 := (if (let4) then let9 else let12); (let let42 := (decide ((let27) = (let41))); (let let43 := (if (let1) then let9 else let12); (let let44 := (decide ((let33) = (let43))); (let let45 := (if (let5) then let9 else let12); (let let46 := e_n0; (let let47 := (decide ((let46) = (let45))); (let let48 := (if (let0) then let9 else let12); (let let49 := (decide ((let21) = (let48))); (let let50 := (if (let6) then let9 else let12); (let let51 := a_n6; (let let52 := (decide ((let51) = (let50))); (let let53 := (((((let52 && let49) && let47) && let44) && let42) && let40); (let let54 := (let53 && let38); (let let55 := (!(let54) || let15); (let let56 := !(let55); let56))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) = true := by
  unfold my_prime at *
  smt_unsat
