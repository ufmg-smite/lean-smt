import Smt
import Smt.ZMod
import Mathlib.Data.ZMod.Basic
set_option maxRecDepth 2000000000000000000000

syntax "smt_unsat" : tactic

macro_rules
  | `(tactic| smt_unsat) => `(tactic| first | smt; trace "unsat")

abbrev my_prime := 52435875175126190479447740508185965837690552500527637822603658699938581184513

theorem compilation_sound_random_04v_001t_ff_zokref_255b_0s [Fact my_prime.Prime]
  (d : Bool) (c : Bool) (b : Bool) (a : Bool) (out : ZMod my_prime) (_6 : ZMod my_prime) (_3 : ZMod my_prime) (_5 : ZMod my_prime) (_4 : ZMod my_prime) (_1 : ZMod my_prime) (_0 : ZMod my_prime) (_2 : ZMod my_prime) :
  (!((let let0 := d; (let let1 := c; (let let2 := b; (let let3 := a; (let let4 := (((let3 && let2) && let1) && let0); (let let5 := out; (let let6 := (1 : ZMod my_prime); (let let7 := (decide ((let6) = (let5))); (let let8 := (decide ((let7) = (let4))); (let let9 := (0 : ZMod my_prime); (let let10 := (decide ((let9) = (let5))); (let let11 := (let7 || let10); (let let12 := (let11 && let8); (let let13 := _6; (let let14 := (decide ((let13) = (let5))); (let let15 := _3; (let let16 := _5; (let let17 := (let16 * let15); (let let18 := (decide ((let17) = (let13))); (let let19 := _4; (let let20 := _1; (let let21 := _0; (let let22 := (let21 * let20); (let let23 := (decide ((let22) = (let19))); (let let24 := (let15 * let15); (let let25 := (decide ((let24) = (let15))); (let let26 := _2; (let let27 := (let26 * let26); (let let28 := (decide ((let27) = (let26))); (let let29 := (let20 * let20); (let let30 := (decide ((let29) = (let20))); (let let31 := (let21 * let21); (let let32 := (decide ((let31) = (let21))); (let let33 := ((((((let32 && let30) && let28) && let25) && let23) && let18) && let14); (let let34 := (if (let2) then let6 else let9); (let let35 := (decide ((let20) = (let34))); (let let36 := (if (let3) then let6 else let9); (let let37 := (decide ((let21) = (let36))); (let let38 := (if (let0) then let6 else let9); (let let39 := (decide ((let15) = (let38))); (let let40 := (if (let1) then let6 else let9); (let let41 := (decide ((let26) = (let40))); (let let42 := (((let41 && let39) && let37) && let35); (let let43 := (let42 && let33); (let let44 := (!(let43) || let12); (let let45 := !(let44); let45)))))))))))))))))))))))))))))))))))))))))))))))) = true := by
  unfold my_prime at *
  smt_unsat
