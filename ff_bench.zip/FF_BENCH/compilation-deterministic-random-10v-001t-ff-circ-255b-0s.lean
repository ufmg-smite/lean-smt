import Smt
import Smt.ZMod
import Mathlib.Data.ZMod.Basic
set_option maxRecDepth 2000000000000000000000

syntax "smt_unsat" : tactic

macro_rules
  | `(tactic| smt_unsat) => `(tactic| first | smt; trace "unsat")

abbrev my_prime := 52435875175126190479447740508185965837690552500527637822603658699938581184513

theorem compilation_deterministic_random_10v_001t_ff_circ_255b_0s [Fact my_prime.Prime]
  (return_n7_alt : ZMod my_prime) (j_n3_alt : ZMod my_prime) (c_n6_alt : ZMod my_prime) (g_n9_alt : ZMod my_prime) (e_n2_alt : ZMod my_prime) (i_n5_alt : ZMod my_prime) (h_n8_alt : ZMod my_prime) (f_n1_alt : ZMod my_prime) (d_n4_alt : ZMod my_prime) (a_n10_alt : ZMod my_prime) (b_n0_alt : ZMod my_prime) (is_zero_inv_n11_alt : ZMod my_prime) (return_n7 : ZMod my_prime) (j_n3 : ZMod my_prime) (c_n6 : ZMod my_prime) (g_n9 : ZMod my_prime) (e_n2 : ZMod my_prime) (i_n5 : ZMod my_prime) (h_n8 : ZMod my_prime) (f_n1 : ZMod my_prime) (d_n4 : ZMod my_prime) (a_n10 : ZMod my_prime) (b_n0 : ZMod my_prime) (is_zero_inv_n11 : ZMod my_prime) :
  (!((let let0 := return_n7_alt; (let let1 := j_n3_alt; (let let2 := c_n6_alt; (let let3 := g_n9_alt; (let let4 := e_n2_alt; (let let5 := i_n5_alt; (let let6 := h_n8_alt; (let let7 := f_n1_alt; (let let8 := d_n4_alt; (let let9 := a_n10_alt; (let let10 := b_n0_alt; (let let11 := (((((((((let10 + let9) + let8) + let7) + let6) + let5) + let4) + let3) + let2) + let1); (let let12 := is_zero_inv_n11_alt; (let let13 := (let12 * let11); (let let14 := (decide ((let13) = (let0))); (let let15 := return_n7; (let let16 := j_n3; (let let17 := c_n6; (let let18 := g_n9; (let let19 := e_n2; (let let20 := i_n5; (let let21 := h_n8; (let let22 := f_n1; (let let23 := d_n4; (let let24 := a_n10; (let let25 := b_n0; (let let26 := (((((((((let25 + let24) + let23) + let22) + let21) + let20) + let19) + let18) + let17) + let16); (let let27 := is_zero_inv_n11; (let let28 := (let27 * let26); (let let29 := (decide ((let28) = (let15))); (let let30 := (decide ((let15) = (let0))); (let let31 := !(let30); (let let32 := (decide ((let21) = (let6))); (let let33 := (decide ((let23) = (let8))); (let let34 := (decide ((let19) = (let4))); (let let35 := (decide ((let25) = (let10))); (let let36 := (decide ((let17) = (let2))); (let let37 := (decide ((let22) = (let7))); (let let38 := (decide ((let20) = (let5))); (let let39 := (decide ((let24) = (let9))); (let let40 := (decide ((let16) = (let1))); (let let41 := (decide ((let18) = (let3))); (let let42 := (((((((((let41 && let40) && let39) && let38) && let37) && let36) && let35) && let34) && let33) && let32); (let let43 := (((let42 && let31) && let29) && let14); let43)))))))))))))))))))))))))))))))))))))))))))))) = true := by
  unfold my_prime at *
  smt_unsat
