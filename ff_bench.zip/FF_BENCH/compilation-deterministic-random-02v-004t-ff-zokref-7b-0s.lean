import Smt
import Smt.ZMod
import Mathlib.Data.ZMod.Basic
set_option maxRecDepth 2000000000000000000000

syntax "smt_unsat" : tactic

macro_rules
  | `(tactic| smt_unsat) => `(tactic| first | smt; trace "unsat")

abbrev my_prime := 67

theorem compilation_deterministic_random_02v_004t_ff_zokref_7b_0s [Fact my_prime.Prime]
  (out_alt : ZMod my_prime) (_6_alt : ZMod my_prime) (_5_alt : ZMod my_prime) (_0_alt : ZMod my_prime) (_4_alt : ZMod my_prime) (_3_alt : ZMod my_prime) (_1_alt : ZMod my_prime) (_2_alt : ZMod my_prime) (out : ZMod my_prime) (_6 : ZMod my_prime) (_5 : ZMod my_prime) (_0 : ZMod my_prime) (_4 : ZMod my_prime) (_3 : ZMod my_prime) (_1 : ZMod my_prime) (_2 : ZMod my_prime) :
  (!((let let0 := out_alt; (let let1 := _6_alt; (let let2 := (decide ((let1) = (let0))); (let let3 := _5_alt; (let let4 := (66 : ZMod my_prime); (let let5 := _0_alt; (let let6 := (let5 * let4); (let let7 := (let6 + let3); (let let8 := (let7 * let7); (let let9 := (decide ((let8) = (let1))); (let let10 := _4_alt; (let let11 := _3_alt; (let let12 := (let11 * let5); (let let13 := (decide ((let12) = (let10))); (let let14 := _1_alt; (let let15 := _2_alt; (let let16 := (let15 * let14); (let let17 := (decide ((let16) = (let11))); (let let18 := (let14 * let5); (let let19 := (decide ((let18) = (let15))); (let let20 := (let14 * let14); (let let21 := (decide ((let20) = (let14))); (let let22 := (let5 * let5); (let let23 := (decide ((let22) = (let5))); (let let24 := ((((((let23 && let21) && let19) && let17) && let13) && let9) && let2); (let let25 := out; (let let26 := _6; (let let27 := (decide ((let26) = (let25))); (let let28 := _5; (let let29 := _0; (let let30 := (let29 * let4); (let let31 := (let30 + let28); (let let32 := (let31 * let31); (let let33 := (decide ((let32) = (let26))); (let let34 := _4; (let let35 := _3; (let let36 := (let35 * let29); (let let37 := (decide ((let36) = (let34))); (let let38 := _1; (let let39 := _2; (let let40 := (let39 * let38); (let let41 := (decide ((let40) = (let35))); (let let42 := (let38 * let29); (let let43 := (decide ((let42) = (let39))); (let let44 := (let38 * let38); (let let45 := (decide ((let44) = (let38))); (let let46 := (let29 * let29); (let let47 := (decide ((let46) = (let29))); (let let48 := ((((((let47 && let45) && let43) && let41) && let37) && let33) && let27); (let let49 := (decide ((let25) = (let0))); (let let50 := !(let49); (let let51 := (decide ((let38) = (let14))); (let let52 := (decide ((let29) = (let5))); (let let53 := (let52 && let51); (let let54 := (((let53 && let50) && let48) && let24); let54))))))))))))))))))))))))))))))))))))))))))))))))))))))))) = true := by
  unfold my_prime at *
  smt_unsat
