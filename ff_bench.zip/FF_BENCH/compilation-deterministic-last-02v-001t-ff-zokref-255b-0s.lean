import Smt
import Smt.ZMod
import Mathlib.Data.ZMod.Basic
set_option maxRecDepth 2000000000000000000000

syntax "smt_unsat" : tactic

macro_rules
  | `(tactic| smt_unsat) => `(tactic| first | smt; trace "unsat")

abbrev my_prime := 52435875175126190479447740508185965837690552500527637822603658699938581184513

theorem compilation_deterministic_last_02v_001t_ff_zokref_255b_0s [Fact my_prime.Prime]
  (_2_alt : ZMod my_prime) (_1_alt : ZMod my_prime) (_0_alt : ZMod my_prime) (_2 : ZMod my_prime) (_1 : ZMod my_prime) (_0 : ZMod my_prime) (out_alt : ZMod my_prime) (out : ZMod my_prime) :
  (!((let let0 := (52435875175126190479447740508185965837690552500527637822603658699938581184512 : ZMod my_prime); (let let1 := _2_alt; (let let2 := (let1 * let0); (let let3 := _1_alt; (let let4 := _0_alt; (let let5 := ((let4 + let3) + let2); (let let6 := (let4 * let3); (let let7 := (decide ((let6) = (let5))); (let let8 := (let3 * let3); (let let9 := (decide ((let8) = (let3))); (let let10 := (let4 * let4); (let let11 := (decide ((let10) = (let4))); (let let12 := ((let11 && let9) && let7); (let let13 := _2; (let let14 := (let13 * let0); (let let15 := _1; (let let16 := _0; (let let17 := ((let16 + let15) + let14); (let let18 := (let16 * let15); (let let19 := (decide ((let18) = (let17))); (let let20 := (let15 * let15); (let let21 := (decide ((let20) = (let15))); (let let22 := (let16 * let16); (let let23 := (decide ((let22) = (let16))); (let let24 := ((let23 && let21) && let19); (let let25 := out_alt; (let let26 := out; (let let27 := (decide ((let26) = (let25))); (let let28 := !(let27); (let let29 := (decide ((let16) = (let4))); (let let30 := (decide ((let15) = (let3))); (let let31 := (let30 && let29); (let let32 := (((let31 && let28) && let24) && let12); let32))))))))))))))))))))))))))))))))))) = true := by
  unfold my_prime at *
  smt_unsat
