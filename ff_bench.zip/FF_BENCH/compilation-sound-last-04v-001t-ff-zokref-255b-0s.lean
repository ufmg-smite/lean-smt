import Smt
import Smt.ZMod
import Mathlib.Data.ZMod.Basic

abbrev k := 52435875175126190479447740508185965837690552500527637822603658699938581184513

theorem compilation_sound_last_04v_001t_ff_zokref_255b_0s [Fact k.Prime]
  (out : ZMod k) (_6 : ZMod k) (_3 : ZMod k) (_5 : ZMod k) (_2 : ZMod k) (_4 : ZMod k) (_1 : ZMod k) (_0 : ZMod k) :
  (let let0 := d; (let let1 := c; (let let2 := b; (let let3 := a; (let let4 := (((let3 ∧ let2) ∧ let1) ∧ let0); (let let5 := out; (let let6 := (1 : ZMod k); (let let7 := ((let6) = (let5)); (let let8 := ((let7) = (let4)); (let let9 := (0 : ZMod k); (let let10 := ((let9) = (let5)); (let let11 := (let7 ∨ let10); (let let12 := (let11 ∧ let8); (let let13 := _6; (let let14 := _3; (let let15 := _5; (let let16 := (let15 * let14); (let let17 := ((let16) = (let13)); (let let18 := _2; (let let19 := _4; (let let20 := (let19 * let18); (let let21 := ((let20) = (let15)); (let let22 := _1; (let let23 := _0; (let let24 := (let23 * let22); (let let25 := ((let24) = (let19)); (let let26 := (let14 * let14); (let let27 := ((let26) = (let14)); (let let28 := (let18 * let18); (let let29 := ((let28) = (let18)); (let let30 := (let22 * let22); (let let31 := ((let30) = (let22)); (let let32 := (let23 * let23); (let let33 := ((let32) = (let23)); (let let34 := ((((((let33 ∧ let31) ∧ let29) ∧ let27) ∧ let25) ∧ let21) ∧ let17); (let let35 := (if let3 then let6 else let9); (let let36 := ((let23) = (let35)); (let let37 := (if let2 then let6 else let9); (let let38 := ((let22) = (let37)); (let let39 := (if let0 then let6 else let9); (let let40 := ((let14) = (let39)); (let let41 := (if let1 then let6 else let9); (let let42 := ((let18) = (let41)); (let let43 := (((let42 ∧ let40) ∧ let38) ∧ let36); (let let44 := (let43 ∧ let34); (let let45 := ((let44) → (let12)); (let let46 := (¬ (let45)); let46))))))))))))))))))))))))))))))))))))))))))))))) := by
  unfold k at *
  smt
