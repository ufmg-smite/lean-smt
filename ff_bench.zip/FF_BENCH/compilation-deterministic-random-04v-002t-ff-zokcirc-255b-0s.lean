import Smt
import Smt.ZMod
import Mathlib.Data.ZMod.Basic
set_option maxRecDepth 2000000000000000000000

syntax "smt_unsat" : tactic

macro_rules
  | `(tactic| smt_unsat) => `(tactic| first | smt; trace "unsat")

abbrev my_prime := 52435875175126190479447740508185965837690552500527637822603658699938581184513

theorem compilation_deterministic_random_04v_002t_ff_zokcirc_255b_0s [Fact my_prime.Prime]
  (return_n2_alt : ZMod my_prime) (d_n0_alt : ZMod my_prime) (mul_n6_alt : ZMod my_prime) (mul_n5_alt : ZMod my_prime) (b_n3_alt : ZMod my_prime) (a_n4_alt : ZMod my_prime) (return_n2 : ZMod my_prime) (d_n0 : ZMod my_prime) (mul_n6 : ZMod my_prime) (mul_n5 : ZMod my_prime) (b_n3 : ZMod my_prime) (a_n4 : ZMod my_prime) (c_n1_alt : ZMod my_prime) (c_n1 : ZMod my_prime) :
  (!((let let0 := (1 : ZMod my_prime); (let let1 := (52435875175126190479447740508185965837690552500527637822603658699938581184512 : ZMod my_prime); (let let2 := return_n2_alt; (let let3 := (let2 * let1); (let let4 := (let3 + let0); (let let5 := d_n0_alt; (let let6 := (let5 * let1); (let let7 := (let6 + let0); (let let8 := mul_n6_alt; (let let9 := (let8 * let7); (let let10 := (decide ((let9) = (let4))); (let let11 := mul_n5_alt; (let let12 := b_n3_alt; (let let13 := (let12 * let1); (let let14 := (let13 + let0); (let let15 := a_n4_alt; (let let16 := (let15 * let1); (let let17 := (let16 + let0); (let let18 := (let17 * let14); (let let19 := (decide ((let18) = (let11))); (let let20 := (let19 && let10); (let let21 := return_n2; (let let22 := (let21 * let1); (let let23 := (let22 + let0); (let let24 := d_n0; (let let25 := (let24 * let1); (let let26 := (let25 + let0); (let let27 := mul_n6; (let let28 := (let27 * let26); (let let29 := (decide ((let28) = (let23))); (let let30 := mul_n5; (let let31 := b_n3; (let let32 := (let31 * let1); (let let33 := (let32 + let0); (let let34 := a_n4; (let let35 := (let34 * let1); (let let36 := (let35 + let0); (let let37 := (let36 * let33); (let let38 := (decide ((let37) = (let30))); (let let39 := (let38 && let29); (let let40 := (decide ((let21) = (let2))); (let let41 := !(let40); (let let42 := (decide ((let24) = (let5))); (let let43 := (decide ((let34) = (let15))); (let let44 := (decide ((let31) = (let12))); (let let45 := c_n1_alt; (let let46 := c_n1; (let let47 := (decide ((let46) = (let45))); (let let48 := (((let47 && let44) && let43) && let42); (let let49 := (((let48 && let41) && let39) && let20); let49)))))))))))))))))))))))))))))))))))))))))))))))))))) = true := by
  unfold my_prime at *
  smt_unsat
