import Smt
import Smt.ZMod
import Mathlib.Data.ZMod.Basic
set_option maxRecDepth 2000000000000000000000

syntax "smt_unsat" : tactic

macro_rules
  | `(tactic| smt_unsat) => `(tactic| first | smt; trace "unsat")

abbrev my_prime := 52435875175126190479447740508185965837690552500527637822603658699938581184513

theorem compilation_deterministic_random_04v_004t_ff_circ_255b_0s [Fact my_prime.Prime]
  (b_n3_alt : ZMod my_prime) (c_n1_alt : ZMod my_prime) (a_n4_alt : ZMod my_prime) (mul_n5_alt : ZMod my_prime) (d_n0_alt : ZMod my_prime) (return_n2_alt : ZMod my_prime) (b_n3 : ZMod my_prime) (c_n1 : ZMod my_prime) (a_n4 : ZMod my_prime) (mul_n5 : ZMod my_prime) (d_n0 : ZMod my_prime) (return_n2 : ZMod my_prime) :
  (!((let let0 := (0 : ZMod my_prime); (let let1 := (6 : ZMod my_prime); (let let2 := (52435875175126190479447740508185965837690552500527637822603658699938581184511 : ZMod my_prime); (let let3 := b_n3_alt; (let let4 := (let3 * let2); (let let5 := (52435875175126190479447740508185965837690552500527637822603658699938581184512 : ZMod my_prime); (let let6 := c_n1_alt; (let let7 := (let6 * let5); (let let8 := a_n4_alt; (let let9 := (let8 * let5); (let let10 := mul_n5_alt; (let let11 := d_n0_alt; (let let12 := (let11 * let2); (let let13 := (((((let12 + let10) + let9) + let7) + let4) + let1); (let let14 := (1 : ZMod my_prime); (let let15 := return_n2_alt; (let let16 := (let15 * let5); (let let17 := (let16 + let14); (let let18 := (let17 * let13); (let let19 := (decide ((let18) = (let0))); (let let20 := (let9 + let14); (let let21 := (let6 * let20); (let let22 := (decide ((let21) = (let10))); (let let23 := (let22 && let19); (let let24 := b_n3; (let let25 := (let24 * let2); (let let26 := c_n1; (let let27 := (let26 * let5); (let let28 := a_n4; (let let29 := (let28 * let5); (let let30 := mul_n5; (let let31 := d_n0; (let let32 := (let31 * let2); (let let33 := (((((let32 + let30) + let29) + let27) + let25) + let1); (let let34 := return_n2; (let let35 := (let34 * let5); (let let36 := (let35 + let14); (let let37 := (let36 * let33); (let let38 := (decide ((let37) = (let0))); (let let39 := (let29 + let14); (let let40 := (let26 * let39); (let let41 := (decide ((let40) = (let30))); (let let42 := (let41 && let38); (let let43 := (decide ((let34) = (let15))); (let let44 := !(let43); (let let45 := (decide ((let24) = (let3))); (let let46 := (decide ((let31) = (let11))); (let let47 := (decide ((let26) = (let6))); (let let48 := (decide ((let28) = (let8))); (let let49 := (((let48 && let47) && let46) && let45); (let let50 := (((let49 && let44) && let42) && let23); let50))))))))))))))))))))))))))))))))))))))))))))))))))))) = true := by
  unfold my_prime at *
  smt_unsat
