import Smt
import Smt.ZMod
import Mathlib.Data.ZMod.Basic

abbrev k := 52435875175126190479447740508185965837690552500527637822603658699938581184513

theorem compilation_deterministic_random_04v_001t_ff_zokcirc_255b_0s [Fact k.Prime]
  (return_n2_alt : ZMod k) (d_n0_alt : ZMod k) (mul_n6_alt : ZMod k) (mul_n5_alt : ZMod k) (b_n3_alt : ZMod k) (a_n4_alt : ZMod k) (return_n2 : ZMod k) (d_n0 : ZMod k) (mul_n6 : ZMod k) (mul_n5 : ZMod k) (b_n3 : ZMod k) (a_n4 : ZMod k) (c_n1_alt : ZMod k) (c_n1 : ZMod k) :
  (let let0 := return_n2_alt; (let let1 := d_n0_alt; (let let2 := mul_n6_alt; (let let3 := (let2 * let1); (let let4 := ((let3) = (let0)); (let let5 := mul_n5_alt; (let let6 := b_n3_alt; (let let7 := a_n4_alt; (let let8 := (let7 * let6); (let let9 := ((let8) = (let5)); (let let10 := (let9 ∧ let4); (let let11 := return_n2; (let let12 := d_n0; (let let13 := mul_n6; (let let14 := (let13 * let12); (let let15 := ((let14) = (let11)); (let let16 := mul_n5; (let let17 := b_n3; (let let18 := a_n4; (let let19 := (let18 * let17); (let let20 := ((let19) = (let16)); (let let21 := (let20 ∧ let15); (let let22 := ((let11) = (let0)); (let let23 := (¬ (let22)); (let let24 := ((let18) = (let7)); (let let25 := ((let17) = (let6)); (let let26 := c_n1_alt; (let let27 := c_n1; (let let28 := ((let27) = (let26)); (let let29 := ((let12) = (let1)); (let let30 := (((let29 ∧ let28) ∧ let25) ∧ let24); (let let31 := (((let30 ∧ let23) ∧ let21) ∧ let10); let31)))))))))))))))))))))))))))))))) := by
  unfold k at *
  smt
