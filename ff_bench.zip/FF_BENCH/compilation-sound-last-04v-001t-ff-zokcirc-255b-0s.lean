import Smt
import Smt.ZMod
import Mathlib.Data.ZMod.Basic
set_option maxRecDepth 2000000000000000000000

syntax "smt_unsat" : tactic

macro_rules
  | `(tactic| smt_unsat) => `(tactic| first | smt; trace "unsat")

abbrev my_prime := 52435875175126190479447740508185965837690552500527637822603658699938581184513

theorem compilation_sound_last_04v_001t_ff_zokcirc_255b_0s [Fact my_prime.Prime]
  (d : Bool) (c : Bool) (b : Bool) (a : Bool) (return_n2 : ZMod my_prime) (mul_n6 : ZMod my_prime) (c_n1 : ZMod my_prime) (mul_n5 : ZMod my_prime) (b_n3 : ZMod my_prime) (a_n4 : ZMod my_prime) (d_n0 : ZMod my_prime) :
  (!((let let0 := d; (let let1 := c; (let let2 := b; (let let3 := a; (let let4 := (((let3 && let2) && let1) && let0); (let let5 := return_n2; (let let6 := (1 : ZMod my_prime); (let let7 := (decide ((let6) = (let5))); (let let8 := (decide ((let7) = (let4))); (let let9 := (0 : ZMod my_prime); (let let10 := (decide ((let9) = (let5))); (let let11 := (let7 || let10); (let let12 := (let11 && let8); (let let13 := mul_n6; (let let14 := c_n1; (let let15 := mul_n5; (let let16 := (let15 * let14); (let let17 := (decide ((let16) = (let13))); (let let18 := b_n3; (let let19 := a_n4; (let let20 := (let19 * let18); (let let21 := (decide ((let20) = (let15))); (let let22 := (let21 && let17); (let let23 := (if (let1) then let6 else let9); (let let24 := (decide ((let14) = (let23))); (let let25 := (if (let2) then let6 else let9); (let let26 := (decide ((let18) = (let25))); (let let27 := (if (let0) then let6 else let9); (let let28 := d_n0; (let let29 := (decide ((let28) = (let27))); (let let30 := (if (let3) then let6 else let9); (let let31 := (decide ((let19) = (let30))); (let let32 := (((let31 && let29) && let26) && let24); (let let33 := (let32 && let22); (let let34 := (!(let33) || let12); (let let35 := !(let34); let35)))))))))))))))))))))))))))))))))))))) = true := by
  unfold my_prime at *
  smt_unsat
