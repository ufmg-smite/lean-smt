import Smt
import Smt.ZMod
import Mathlib.Data.ZMod.Basic

abbrev k := 52435875175126190479447740508185965837690552500527637822603658699938581184513

theorem compilation_deterministic_last_02v_004t_ff_zokcirc_255b_0s [Fact k.Prime]
  (mul_n6_alt : ZMod k) (a_n2_alt : ZMod k) (mul_n5_alt : ZMod k) (mul_n4_alt : ZMod k) (b_n1_alt : ZMod k) (mul_n3_alt : ZMod k) (mul_n6 : ZMod k) (a_n2 : ZMod k) (mul_n5 : ZMod k) (mul_n4 : ZMod k) (b_n1 : ZMod k) (mul_n3 : ZMod k) (return_n0_alt : ZMod k) (return_n0 : ZMod k) :
  (let let0 := mul_n6_alt; (let let1 := a_n2_alt; (let let2 := mul_n5_alt; (let let3 := (let2 * let1); (let let4 := ((let3) = (let0)); (let let5 := mul_n4_alt; (let let6 := (let5 * let1); (let let7 := ((let6) = (let2)); (let let8 := b_n1_alt; (let let9 := mul_n3_alt; (let let10 := (let9 * let8); (let let11 := ((let10) = (let5)); (let let12 := (let8 * let1); (let let13 := ((let12) = (let9)); (let let14 := (((let13 ∧ let11) ∧ let7) ∧ let4); (let let15 := mul_n6; (let let16 := a_n2; (let let17 := mul_n5; (let let18 := (let17 * let16); (let let19 := ((let18) = (let15)); (let let20 := mul_n4; (let let21 := (let20 * let16); (let let22 := ((let21) = (let17)); (let let23 := b_n1; (let let24 := mul_n3; (let let25 := (let24 * let23); (let let26 := ((let25) = (let20)); (let let27 := (let23 * let16); (let let28 := ((let27) = (let24)); (let let29 := (((let28 ∧ let26) ∧ let22) ∧ let19); (let let30 := return_n0_alt; (let let31 := return_n0; (let let32 := ((let31) = (let30)); (let let33 := (¬ (let32)); (let let34 := ((let23) = (let8)); (let let35 := ((let16) = (let1)); (let let36 := (let35 ∧ let34); (let let37 := (((let36 ∧ let33) ∧ let29) ∧ let14); let37)))))))))))))))))))))))))))))))))))))) := by
  unfold k at *
  smt
