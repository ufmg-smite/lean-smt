import Smt
import Smt.ZMod
import Mathlib.Data.ZMod.Basic
set_option maxRecDepth 2000000000000000000000

syntax "smt_unsat" : tactic

macro_rules
  | `(tactic| smt_unsat) => `(tactic| first | smt; trace "unsat")

abbrev my_prime := 52435875175126190479447740508185965837690552500527637822603658699938581184513

theorem compilation_deterministic_last_02v_002t_ff_zokref_255b_0s [Fact my_prime.Prime]
  (_3_alt : ZMod my_prime) (_2_alt : ZMod my_prime) (_1_alt : ZMod my_prime) (_0_alt : ZMod my_prime) (_3 : ZMod my_prime) (_2 : ZMod my_prime) (_1 : ZMod my_prime) (_0 : ZMod my_prime) (out_alt : ZMod my_prime) (out : ZMod my_prime) :
  (!((let let0 := (52435875175126190479447740508185965837690552500527637822603658699938581184512 : ZMod my_prime); (let let1 := _3_alt; (let let2 := (let1 * let0); (let let3 := _2_alt; (let let4 := _1_alt; (let let5 := ((let4 + let3) + let2); (let let6 := (let3 * let4); (let let7 := (decide ((let6) = (let5))); (let let8 := (let3 * let0); (let let9 := _0_alt; (let let10 := ((let9 + let4) + let8); (let let11 := (let9 * let4); (let let12 := (decide ((let11) = (let10))); (let let13 := (let4 * let4); (let let14 := (decide ((let13) = (let4))); (let let15 := (let9 * let9); (let let16 := (decide ((let15) = (let9))); (let let17 := (((let16 && let14) && let12) && let7); (let let18 := _3; (let let19 := (let18 * let0); (let let20 := _2; (let let21 := _1; (let let22 := ((let21 + let20) + let19); (let let23 := (let20 * let21); (let let24 := (decide ((let23) = (let22))); (let let25 := (let20 * let0); (let let26 := _0; (let let27 := ((let26 + let21) + let25); (let let28 := (let26 * let21); (let let29 := (decide ((let28) = (let27))); (let let30 := (let21 * let21); (let let31 := (decide ((let30) = (let21))); (let let32 := (let26 * let26); (let let33 := (decide ((let32) = (let26))); (let let34 := (((let33 && let31) && let29) && let24); (let let35 := out_alt; (let let36 := out; (let let37 := (decide ((let36) = (let35))); (let let38 := !(let37); (let let39 := (decide ((let26) = (let9))); (let let40 := (decide ((let21) = (let4))); (let let41 := (let40 && let39); (let let42 := (((let41 && let38) && let34) && let17); let42))))))))))))))))))))))))))))))))))))))))))))) = true := by
  unfold my_prime at *
  smt_unsat
