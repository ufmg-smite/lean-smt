import Smt
import Smt.ZMod
import Mathlib.Data.ZMod.Basic
set_option maxRecDepth 2000000000000000000000

syntax "smt_unsat" : tactic

macro_rules
  | `(tactic| smt_unsat) => `(tactic| first | smt; trace "unsat")

abbrev my_prime := 52435875175126190479447740508185965837690552500527637822603658699938581184513

theorem compilation_sound_random_02v_008t_ff_circ_255b_0s [Fact my_prime.Prime]
  (a : Bool) (b : Bool) (return_n0 : ZMod my_prime) (mul_n3 : ZMod my_prime) (a_n2 : ZMod my_prime) (mul_n7 : ZMod my_prime) (b_n1 : ZMod my_prime) (mul_n4 : ZMod my_prime) (mul_n6 : ZMod my_prime) (mul_n5 : ZMod my_prime) :
  (!((let let0 := a; (let let1 := !(let0); (let let2 := !(let1); (let let3 := (decide ((let2) = (let0))); (let let4 := b; (let let5 := (decide ((let4) = (let4))); (let let6 := (decide ((let2) = (let4))); (let let7 := (if (let1) then let0 else let6); (let let8 := (if (let6) then let7 else let5); (let let9 := (let8 || let3); (let let10 := return_n0; (let let11 := (1 : ZMod my_prime); (let let12 := (decide ((let11) = (let10))); (let let13 := (decide ((let12) = (let9))); (let let14 := (0 : ZMod my_prime); (let let15 := (decide ((let14) = (let10))); (let let16 := (let12 || let15); (let let17 := (let16 && let13); (let let18 := (52435875175126190479447740508185965837690552500527637822603658699938581184512 : ZMod my_prime); (let let19 := (let10 * let18); (let let20 := (let19 + let11); (let let21 := mul_n3; (let let22 := (let21 * let18); (let let23 := (2 : ZMod my_prime); (let let24 := a_n2; (let let25 := (let24 * let23); (let let26 := (let25 + let22); (let let27 := mul_n7; (let let28 := (let27 * let18); (let let29 := b_n1; (let let30 := (let29 * let23); (let let31 := mul_n4; (let let32 := (let31 * let18); (let let33 := ((let32 + let30) + let28); (let let34 := (let33 * let26); (let let35 := (decide ((let34) = (let20))); (let let36 := mul_n6; (let let37 := mul_n5; (let let38 := (let37 * let18); (let let39 := (((let38 + let25) + let29) + let18); (let let40 := (let24 * let18); (let let41 := (let40 + let11); (let let42 := (let41 * let39); (let let43 := (decide ((let42) = (let36))); (let let44 := (let25 * let29); (let let45 := (decide ((let44) = (let37))); (let let46 := (let30 * let29); (let let47 := (decide ((let46) = (let31))); (let let48 := (let25 * let24); (let let49 := (decide ((let48) = (let21))); (let let50 := ((((let49 && let47) && let45) && let43) && let35); (let let51 := (if (let4) then let11 else let14); (let let52 := (decide ((let29) = (let51))); (let let53 := (if (let0) then let11 else let14); (let let54 := (decide ((let24) = (let53))); (let let55 := (let54 && let52); (let let56 := (let55 && let50); (let let57 := (!(let56) || let17); (let let58 := !(let57); let58))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) = true := by
  unfold my_prime at *
  smt_unsat
