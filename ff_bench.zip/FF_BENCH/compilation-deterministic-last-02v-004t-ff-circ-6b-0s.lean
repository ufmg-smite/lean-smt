import Smt
import Smt.ZMod
import Mathlib.Data.ZMod.Basic
set_option maxRecDepth 2000000000000000000000

syntax "smt_unsat" : tactic

macro_rules
  | `(tactic| smt_unsat) => `(tactic| first | smt; trace "unsat")

abbrev my_prime := 37

theorem compilation_deterministic_last_02v_004t_ff_circ_6b_0s [Fact my_prime.Prime]
  (a_n2_alt : ZMod my_prime) (b_n1_alt : ZMod my_prime) (is_zero_n4_alt : ZMod my_prime) (is_zero_inv_n3_alt : ZMod my_prime) (a_n2 : ZMod my_prime) (b_n1 : ZMod my_prime) (is_zero_n4 : ZMod my_prime) (is_zero_inv_n3 : ZMod my_prime) (return_n0_alt : ZMod my_prime) (return_n0 : ZMod my_prime) :
  (!((let let0 := (0 : ZMod my_prime); (let let1 := (5 : ZMod my_prime); (let let2 := (34 : ZMod my_prime); (let let3 := a_n2_alt; (let let4 := (let3 * let2); (let let5 := (35 : ZMod my_prime); (let let6 := b_n1_alt; (let let7 := (let6 * let5); (let let8 := ((let7 + let4) + let1); (let let9 := is_zero_n4_alt; (let let10 := (let9 * let8); (let let11 := (decide ((let10) = (let0))); (let let12 := (1 : ZMod my_prime); (let let13 := (36 : ZMod my_prime); (let let14 := (let9 * let13); (let let15 := (let14 + let12); (let let16 := is_zero_inv_n3_alt; (let let17 := (let16 * let8); (let let18 := (decide ((let17) = (let15))); (let let19 := (let18 && let11); (let let20 := a_n2; (let let21 := (let20 * let2); (let let22 := b_n1; (let let23 := (let22 * let5); (let let24 := ((let23 + let21) + let1); (let let25 := is_zero_n4; (let let26 := (let25 * let24); (let let27 := (decide ((let26) = (let0))); (let let28 := (let25 * let13); (let let29 := (let28 + let12); (let let30 := is_zero_inv_n3; (let let31 := (let30 * let24); (let let32 := (decide ((let31) = (let29))); (let let33 := (let32 && let27); (let let34 := return_n0_alt; (let let35 := return_n0; (let let36 := (decide ((let35) = (let34))); (let let37 := !(let36); (let let38 := (decide ((let22) = (let6))); (let let39 := (decide ((let20) = (let3))); (let let40 := (let39 && let38); (let let41 := (((let40 && let37) && let33) && let19); let41)))))))))))))))))))))))))))))))))))))))))))) = true := by
  unfold my_prime at *
  smt_unsat
