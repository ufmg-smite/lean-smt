import Smt
import Smt.ZMod
import Mathlib.Data.ZMod.Basic
set_option maxRecDepth 2000000000000000000000

syntax "smt_unsat" : tactic

macro_rules
  | `(tactic| smt_unsat) => `(tactic| first | smt; trace "unsat")

abbrev my_prime := 52435875175126190479447740508185965837690552500527637822603658699938581184513

theorem compilation_sound_none_06v_001t_ff_zokref_255b_0s [Fact my_prime.Prime]
  (f : Bool) (e : Bool) (d : Bool) (c : Bool) (b : Bool) (a : Bool) (out : ZMod my_prime) (_10 : ZMod my_prime) (_5 : ZMod my_prime) (_9 : ZMod my_prime) (_4 : ZMod my_prime) (_8 : ZMod my_prime) (_3 : ZMod my_prime) (_7 : ZMod my_prime) (_2 : ZMod my_prime) (_6 : ZMod my_prime) (_1 : ZMod my_prime) (_0 : ZMod my_prime) :
  (!((let let0 := f; (let let1 := e; (let let2 := d; (let let3 := c; (let let4 := b; (let let5 := a; (let let6 := (((((let5 && let4) && let3) && let2) && let1) && let0); (let let7 := out; (let let8 := (1 : ZMod my_prime); (let let9 := (decide ((let8) = (let7))); (let let10 := (decide ((let9) = (let6))); (let let11 := (0 : ZMod my_prime); (let let12 := (decide ((let11) = (let7))); (let let13 := (let9 || let12); (let let14 := (let13 && let10); (let let15 := _10; (let let16 := (decide ((let15) = (let7))); (let let17 := _5; (let let18 := _9; (let let19 := (let18 * let17); (let let20 := (decide ((let19) = (let15))); (let let21 := _4; (let let22 := _8; (let let23 := (let22 * let21); (let let24 := (decide ((let23) = (let18))); (let let25 := _3; (let let26 := _7; (let let27 := (let26 * let25); (let let28 := (decide ((let27) = (let22))); (let let29 := _2; (let let30 := _6; (let let31 := (let30 * let29); (let let32 := (decide ((let31) = (let26))); (let let33 := _1; (let let34 := _0; (let let35 := (let34 * let33); (let let36 := (decide ((let35) = (let30))); (let let37 := (let17 * let17); (let let38 := (decide ((let37) = (let17))); (let let39 := (let21 * let21); (let let40 := (decide ((let39) = (let21))); (let let41 := (let25 * let25); (let let42 := (decide ((let41) = (let25))); (let let43 := (let29 * let29); (let let44 := (decide ((let43) = (let29))); (let let45 := (let33 * let33); (let let46 := (decide ((let45) = (let33))); (let let47 := (let34 * let34); (let let48 := (decide ((let47) = (let34))); (let let49 := (((((((((((let48 && let46) && let44) && let42) && let40) && let38) && let36) && let32) && let28) && let24) && let20) && let16); (let let50 := (if (let5) then let8 else let11); (let let51 := (decide ((let34) = (let50))); (let let52 := (if (let0) then let8 else let11); (let let53 := (decide ((let17) = (let52))); (let let54 := (if (let3) then let8 else let11); (let let55 := (decide ((let29) = (let54))); (let let56 := (if (let1) then let8 else let11); (let let57 := (decide ((let21) = (let56))); (let let58 := (if (let4) then let8 else let11); (let let59 := (decide ((let33) = (let58))); (let let60 := (if (let2) then let8 else let11); (let let61 := (decide ((let25) = (let60))); (let let62 := (((((let61 && let59) && let57) && let55) && let53) && let51); (let let63 := (let62 && let49); (let let64 := (!(let63) || let14); (let let65 := !(let64); let65)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) = true := by
  unfold my_prime at *
  smt_unsat
