import Smt
import Smt.ZMod
import Mathlib.Data.ZMod.Basic
set_option maxRecDepth 2000000000000000000000

syntax "smt_unsat" : tactic

macro_rules
  | `(tactic| smt_unsat) => `(tactic| first | smt; trace "unsat")

abbrev my_prime := 52435875175126190479447740508185965837690552500527637822603658699938581184513

theorem compilation_deterministic_last_06v_004t_ff_circ_255b_0s [Fact my_prime.Prime]
  (mul_n10_alt : ZMod my_prime) (c_n2_alt : ZMod my_prime) (mul_n9_alt : ZMod my_prime) (e_n6_alt : ZMod my_prime) (a_n0_alt : ZMod my_prime) (mul_n8_alt : ZMod my_prime) (b_n4_alt : ZMod my_prime) (mul_n7_alt : ZMod my_prime) (d_n1_alt : ZMod my_prime) (mul_n10 : ZMod my_prime) (c_n2 : ZMod my_prime) (mul_n9 : ZMod my_prime) (e_n6 : ZMod my_prime) (a_n0 : ZMod my_prime) (mul_n8 : ZMod my_prime) (b_n4 : ZMod my_prime) (mul_n7 : ZMod my_prime) (d_n1 : ZMod my_prime) (return_n3_alt : ZMod my_prime) (return_n3 : ZMod my_prime) (f_n5_alt : ZMod my_prime) (f_n5 : ZMod my_prime) :
  (!((let let0 := mul_n10_alt; (let let1 := c_n2_alt; (let let2 := (52435875175126190479447740508185965837690552500527637822603658699938581184512 : ZMod my_prime); (let let3 := mul_n9_alt; (let let4 := (let3 * let2); (let let5 := (let4 + let1); (let let6 := e_n6_alt; (let let7 := (let6 * let5); (let let8 := (decide ((let7) = (let0))); (let let9 := a_n0_alt; (let let10 := mul_n8_alt; (let let11 := (let10 * let9); (let let12 := (decide ((let11) = (let3))); (let let13 := b_n4_alt; (let let14 := (1 : ZMod my_prime); (let let15 := mul_n7_alt; (let let16 := (let1 * let2); (let let17 := d_n1_alt; (let let18 := (let17 * let2); (let let19 := (((let18 + let16) + let15) + let14); (let let20 := (let19 * let13); (let let21 := (decide ((let20) = (let10))); (let let22 := (2 : ZMod my_prime); (let let23 := (let1 * let22); (let let24 := (let23 * let17); (let let25 := (decide ((let24) = (let15))); (let let26 := (((let25 && let21) && let12) && let8); (let let27 := mul_n10; (let let28 := c_n2; (let let29 := mul_n9; (let let30 := (let29 * let2); (let let31 := (let30 + let28); (let let32 := e_n6; (let let33 := (let32 * let31); (let let34 := (decide ((let33) = (let27))); (let let35 := a_n0; (let let36 := mul_n8; (let let37 := (let36 * let35); (let let38 := (decide ((let37) = (let29))); (let let39 := b_n4; (let let40 := mul_n7; (let let41 := (let28 * let2); (let let42 := d_n1; (let let43 := (let42 * let2); (let let44 := (((let43 + let41) + let40) + let14); (let let45 := (let44 * let39); (let let46 := (decide ((let45) = (let36))); (let let47 := (let28 * let22); (let let48 := (let47 * let42); (let let49 := (decide ((let48) = (let40))); (let let50 := (((let49 && let46) && let38) && let34); (let let51 := return_n3_alt; (let let52 := return_n3; (let let53 := (decide ((let52) = (let51))); (let let54 := !(let53); (let let55 := (decide ((let42) = (let17))); (let let56 := (decide ((let39) = (let13))); (let let57 := f_n5_alt; (let let58 := f_n5; (let let59 := (decide ((let58) = (let57))); (let let60 := (decide ((let32) = (let6))); (let let61 := (decide ((let28) = (let1))); (let let62 := (decide ((let35) = (let9))); (let let63 := (((((let62 && let61) && let60) && let59) && let56) && let55); (let let64 := (((let63 && let54) && let50) && let26); let64))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) = true := by
  unfold my_prime at *
  smt_unsat
