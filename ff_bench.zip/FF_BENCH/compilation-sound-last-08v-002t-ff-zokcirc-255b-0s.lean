import Smt
import Smt.ZMod
import Mathlib.Data.ZMod.Basic
set_option maxRecDepth 2000000000000000000000

syntax "smt_unsat" : tactic

macro_rules
  | `(tactic| smt_unsat) => `(tactic| first | smt; trace "unsat")

abbrev my_prime := 52435875175126190479447740508185965837690552500527637822603658699938581184513

theorem compilation_sound_last_08v_002t_ff_zokcirc_255b_0s [Fact my_prime.Prime]
  (e : Bool) (d : Bool) (h : Bool) (g : Bool) (f : Bool) (c : Bool) (b : Bool) (a : Bool) (return_n0 : ZMod my_prime) (mul_n14 : ZMod my_prime) (h_n5 : ZMod my_prime) (mul_n13 : ZMod my_prime) (g_n7 : ZMod my_prime) (mul_n12 : ZMod my_prime) (f_n1 : ZMod my_prime) (mul_n11 : ZMod my_prime) (c_n4 : ZMod my_prime) (mul_n10 : ZMod my_prime) (b_n6 : ZMod my_prime) (a_n8 : ZMod my_prime) (mul_n9 : ZMod my_prime) (e_n2 : ZMod my_prime) (d_n3 : ZMod my_prime) :
  (!((let let0 := e; (let let1 := d; (let let2 := (decide ((let1) = (let0))); (let let3 := h; (let let4 := g; (let let5 := f; (let let6 := c; (let let7 := b; (let let8 := a; (let let9 := ((((((let8 && let7) && let6) && let5) && let4) && let3) && let2); (let let10 := return_n0; (let let11 := (1 : ZMod my_prime); (let let12 := (decide ((let11) = (let10))); (let let13 := (decide ((let12) = (let9))); (let let14 := (0 : ZMod my_prime); (let let15 := (decide ((let14) = (let10))); (let let16 := (let12 || let15); (let let17 := (let16 && let13); (let let18 := mul_n14; (let let19 := h_n5; (let let20 := mul_n13; (let let21 := (let20 * let19); (let let22 := (decide ((let21) = (let18))); (let let23 := g_n7; (let let24 := mul_n12; (let let25 := (let24 * let23); (let let26 := (decide ((let25) = (let20))); (let let27 := f_n1; (let let28 := mul_n11; (let let29 := (let28 * let27); (let let30 := (decide ((let29) = (let24))); (let let31 := c_n4; (let let32 := mul_n10; (let let33 := (let32 * let31); (let let34 := (decide ((let33) = (let28))); (let let35 := b_n6; (let let36 := a_n8; (let let37 := (let36 * let35); (let let38 := (decide ((let37) = (let32))); (let let39 := mul_n9; (let let40 := e_n2; (let let41 := (2 : ZMod my_prime); (let let42 := d_n3; (let let43 := (let42 * let41); (let let44 := (let43 * let40); (let let45 := (decide ((let44) = (let39))); (let let46 := (((((let45 && let38) && let34) && let30) && let26) && let22); (let let47 := (if (let4) then let11 else let14); (let let48 := (decide ((let23) = (let47))); (let let49 := (if (let1) then let11 else let14); (let let50 := (decide ((let42) = (let49))); (let let51 := (if (let6) then let11 else let14); (let let52 := (decide ((let31) = (let51))); (let let53 := (if (let3) then let11 else let14); (let let54 := (decide ((let19) = (let53))); (let let55 := (if (let5) then let11 else let14); (let let56 := (decide ((let27) = (let55))); (let let57 := (if (let0) then let11 else let14); (let let58 := (decide ((let40) = (let57))); (let let59 := (if (let7) then let11 else let14); (let let60 := (decide ((let35) = (let59))); (let let61 := (if (let8) then let11 else let14); (let let62 := (decide ((let36) = (let61))); (let let63 := (((((((let62 && let60) && let58) && let56) && let54) && let52) && let50) && let48); (let let64 := (let63 && let46); (let let65 := (!(let64) || let17); (let let66 := !(let65); let66))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) = true := by
  unfold my_prime at *
  smt_unsat
