import Smt
import Smt.ZMod
import Mathlib.Data.ZMod.Basic
set_option maxRecDepth 2000000000000000000000

syntax "smt_unsat" : tactic

macro_rules
  | `(tactic| smt_unsat) => `(tactic| first | smt; trace "unsat")

abbrev my_prime := 52435875175126190479447740508185965837690552500527637822603658699938581184513

theorem compilation_sound_last_04v_004t_ff_circ_255b_0s [Fact my_prime.Prime]
  (c : Bool) (a : Bool) (d : Bool) (b : Bool) (return_n2 : ZMod my_prime) (c_n1 : ZMod my_prime) (a_n4 : ZMod my_prime) (is_zero_n7 : ZMod my_prime) (mul_n5 : ZMod my_prime) (d_n0 : ZMod my_prime) (is_zero_inv_n8 : ZMod my_prime) (b_n3 : ZMod my_prime) (is_zero_inv_n6 : ZMod my_prime) :
  (!((let let0 := c; (let let1 := a; (let let2 := d; (let let3 := b; (let let4 := (!(let1) || let3); (let let5 := ((((let2 && let4) && let1) && let3) && let3); (let let6 := ((((((let4 || let5) || let5) || let2) || let2) || let1) || let0); (let let7 := return_n2; (let let8 := (1 : ZMod my_prime); (let let9 := (decide ((let8) = (let7))); (let let10 := (decide ((let9) = (let6))); (let let11 := (0 : ZMod my_prime); (let let12 := (decide ((let11) = (let7))); (let let13 := (let9 || let12); (let let14 := (let13 && let10); (let let15 := c_n1; (let let16 := a_n4; (let let17 := (2 : ZMod my_prime); (let let18 := is_zero_n7; (let let19 := (let18 * let17); (let let20 := (52435875175126190479447740508185965837690552500527637822603658699938581184512 : ZMod my_prime); (let let21 := mul_n5; (let let22 := (let21 * let20); (let let23 := d_n0; (let let24 := (let23 * let17); (let let25 := (((((let24 + let22) + let19) + let16) + let15) + let8); (let let26 := is_zero_inv_n8; (let let27 := (let26 * let25); (let let28 := (decide ((let27) = (let7))); (let let29 := (4 : ZMod my_prime); (let let30 := (52435875175126190479447740508185965837690552500527637822603658699938581184511 : ZMod my_prime); (let let31 := b_n3; (let let32 := (let31 * let30); (let let33 := (let16 * let20); (let let34 := (let23 * let20); (let let35 := ((((let34 + let21) + let33) + let32) + let29); (let let36 := (let18 * let35); (let let37 := (decide ((let36) = (let11))); (let let38 := (let18 * let20); (let let39 := (let38 + let8); (let let40 := is_zero_inv_n6; (let let41 := (let40 * let35); (let let42 := (decide ((let41) = (let39))); (let let43 := (let31 * let20); (let let44 := (let43 + let8); (let let45 := (let16 * let44); (let let46 := (decide ((let45) = (let21))); (let let47 := (((let46 && let42) && let37) && let28); (let let48 := (if (let3) then let8 else let11); (let let49 := (decide ((let31) = (let48))); (let let50 := (if (let2) then let8 else let11); (let let51 := (decide ((let23) = (let50))); (let let52 := (if (let1) then let8 else let11); (let let53 := (decide ((let16) = (let52))); (let let54 := (if (let0) then let8 else let11); (let let55 := (decide ((let15) = (let54))); (let let56 := (((let55 && let53) && let51) && let49); (let let57 := (let56 && let47); (let let58 := (!(let57) || let14); (let let59 := !(let58); let59)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) = true := by
  unfold my_prime at *
  smt_unsat
