import Smt
import Smt.ZMod
import Mathlib.Data.ZMod.Basic

abbrev k := 52435875175126190479447740508185965837690552500527637822603658699938581184513

theorem compilation_sound_last_02v_004t_ff_zokcirc_255b_0s [Fact k.Prime]
  (return_n0 : ZMod k) (mul_n4 : ZMod k) (a_n2 : ZMod k) (b_n1 : ZMod k) (mul_n3 : ZMod k) :
  (let let0 := a; (let let1 := b; (let let2 := ((let1) → (let0)); (let let3 := (¬ (let2)); (let let4 := (if let2 then let1 else let0); (let let5 := (let4 ∧ let3); (let let6 := return_n0; (let let7 := (1 : ZMod k); (let let8 := ((let7) = (let6)); (let let9 := ((let8) = (let5)); (let let10 := (0 : ZMod k); (let let11 := ((let10) = (let6)); (let let12 := (let8 ∨ let11); (let let13 := (let12 ∧ let9); (let let14 := mul_n4; (let let15 := (52435875175126190479447740508185965837690552500527637822603658699938581184512 : ZMod k); (let let16 := a_n2; (let let17 := (let16 * let15); (let let18 := b_n1; (let let19 := (let18 + let17); (let let20 := mul_n3; (let let21 := (let20 * let15); (let let22 := (let21 + let7); (let let23 := (let22 * let19); (let let24 := ((let23) = (let14)); (let let25 := (let17 + let7); (let let26 := (let18 * let25); (let let27 := ((let26) = (let20)); (let let28 := (let27 ∧ let24); (let let29 := (if let1 then let7 else let10); (let let30 := ((let18) = (let29)); (let let31 := (if let0 then let7 else let10); (let let32 := ((let16) = (let31)); (let let33 := (let32 ∧ let30); (let let34 := (let33 ∧ let28); (let let35 := ((let34) → (let13)); (let let36 := (¬ (let35)); let36))))))))))))))))))))))))))))))))))))) := by
  unfold k at *
  smt
