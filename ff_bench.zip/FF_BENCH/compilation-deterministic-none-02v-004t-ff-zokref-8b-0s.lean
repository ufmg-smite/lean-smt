import Smt
import Smt.ZMod
import Mathlib.Data.ZMod.Basic
set_option maxRecDepth 2000000000000000000000

syntax "smt_unsat" : tactic

macro_rules
  | `(tactic| smt_unsat) => `(tactic| first | smt; trace "unsat")

abbrev my_prime := 131

theorem compilation_deterministic_none_02v_004t_ff_zokref_8b_0s [Fact my_prime.Prime]
  (out_alt : ZMod my_prime) (_6_alt : ZMod my_prime) (_5_alt : ZMod my_prime) (_0_alt : ZMod my_prime) (_4_alt : ZMod my_prime) (_3_alt : ZMod my_prime) (_1_alt : ZMod my_prime) (_2_alt : ZMod my_prime) (out : ZMod my_prime) (_6 : ZMod my_prime) (_5 : ZMod my_prime) (_0 : ZMod my_prime) (_4 : ZMod my_prime) (_3 : ZMod my_prime) (_1 : ZMod my_prime) (_2 : ZMod my_prime) :
  (!((let let0 := out_alt; (let let1 := _6_alt; (let let2 := (decide ((let1) = (let0))); (let let3 := _5_alt; (let let4 := (130 : ZMod my_prime); (let let5 := _0_alt; (let let6 := (let5 * let4); (let let7 := (let6 + let3); (let let8 := (let7 * let7); (let let9 := (decide ((let8) = (let1))); (let let10 := _4_alt; (let let11 := (let10 * let5); (let let12 := (decide ((let11) = (let3))); (let let13 := _3_alt; (let let14 := (let13 * let5); (let let15 := (decide ((let14) = (let10))); (let let16 := _1_alt; (let let17 := _2_alt; (let let18 := (let17 * let16); (let let19 := (decide ((let18) = (let13))); (let let20 := (let16 * let5); (let let21 := (decide ((let20) = (let17))); (let let22 := (let16 * let16); (let let23 := (decide ((let22) = (let16))); (let let24 := (let5 * let5); (let let25 := (decide ((let24) = (let5))); (let let26 := (((((((let25 && let23) && let21) && let19) && let15) && let12) && let9) && let2); (let let27 := out; (let let28 := _6; (let let29 := (decide ((let28) = (let27))); (let let30 := _5; (let let31 := _0; (let let32 := (let31 * let4); (let let33 := (let32 + let30); (let let34 := (let33 * let33); (let let35 := (decide ((let34) = (let28))); (let let36 := _4; (let let37 := (let36 * let31); (let let38 := (decide ((let37) = (let30))); (let let39 := _3; (let let40 := (let39 * let31); (let let41 := (decide ((let40) = (let36))); (let let42 := _1; (let let43 := _2; (let let44 := (let43 * let42); (let let45 := (decide ((let44) = (let39))); (let let46 := (let42 * let31); (let let47 := (decide ((let46) = (let43))); (let let48 := (let42 * let42); (let let49 := (decide ((let48) = (let42))); (let let50 := (let31 * let31); (let let51 := (decide ((let50) = (let31))); (let let52 := (((((((let51 && let49) && let47) && let45) && let41) && let38) && let35) && let29); (let let53 := (decide ((let27) = (let0))); (let let54 := !(let53); (let let55 := (decide ((let42) = (let16))); (let let56 := (decide ((let31) = (let5))); (let let57 := (let56 && let55); (let let58 := (((let57 && let54) && let52) && let26); let58))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) = true := by
  unfold my_prime at *
  smt_unsat
