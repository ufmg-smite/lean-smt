import Smt
import Smt.ZMod
import Mathlib.Data.ZMod.Basic
set_option maxRecDepth 2000000000000000000000

syntax "smt_unsat" : tactic

macro_rules
  | `(tactic| smt_unsat) => `(tactic| first | smt; trace "unsat")

abbrev my_prime := 1031

theorem compilation_deterministic_none_02v_004t_ff_circ_11b_0s [Fact my_prime.Prime]
  (a_n2_alt : ZMod my_prime) (is_zero_n4_alt : ZMod my_prime) (return_n0_alt : ZMod my_prime) (b_n1_alt : ZMod my_prime) (is_zero_inv_n3_alt : ZMod my_prime) (a_n2 : ZMod my_prime) (is_zero_n4 : ZMod my_prime) (return_n0 : ZMod my_prime) (b_n1 : ZMod my_prime) (is_zero_inv_n3 : ZMod my_prime) :
  (!((let let0 := a_n2_alt; (let let1 := is_zero_n4_alt; (let let2 := (1030 : ZMod my_prime); (let let3 := return_n0_alt; (let let4 := (let3 * let2); (let let5 := ((let4 + let1) + let0); (let let6 := (2 : ZMod my_prime); (let let7 := (let1 * let6); (let let8 := (let7 * let0); (let let9 := (decide ((let8) = (let5))); (let let10 := (0 : ZMod my_prime); (let let11 := (5 : ZMod my_prime); (let let12 := (1028 : ZMod my_prime); (let let13 := (let0 * let12); (let let14 := (1029 : ZMod my_prime); (let let15 := b_n1_alt; (let let16 := (let15 * let14); (let let17 := ((let16 + let13) + let11); (let let18 := (let1 * let17); (let let19 := (decide ((let18) = (let10))); (let let20 := (1 : ZMod my_prime); (let let21 := (let1 * let2); (let let22 := (let21 + let20); (let let23 := is_zero_inv_n3_alt; (let let24 := (let23 * let17); (let let25 := (decide ((let24) = (let22))); (let let26 := ((let25 && let19) && let9); (let let27 := a_n2; (let let28 := is_zero_n4; (let let29 := return_n0; (let let30 := (let29 * let2); (let let31 := ((let30 + let28) + let27); (let let32 := (let28 * let6); (let let33 := (let32 * let27); (let let34 := (decide ((let33) = (let31))); (let let35 := (let27 * let12); (let let36 := b_n1; (let let37 := (let36 * let14); (let let38 := ((let37 + let35) + let11); (let let39 := (let28 * let38); (let let40 := (decide ((let39) = (let10))); (let let41 := (let28 * let2); (let let42 := (let41 + let20); (let let43 := is_zero_inv_n3; (let let44 := (let43 * let38); (let let45 := (decide ((let44) = (let42))); (let let46 := ((let45 && let40) && let34); (let let47 := (decide ((let29) = (let3))); (let let48 := !(let47); (let let49 := (decide ((let27) = (let0))); (let let50 := (decide ((let36) = (let15))); (let let51 := (let50 && let49); (let let52 := (((let51 && let48) && let46) && let26); let52))))))))))))))))))))))))))))))))))))))))))))))))))))))) = true := by
  unfold my_prime at *
  smt_unsat
