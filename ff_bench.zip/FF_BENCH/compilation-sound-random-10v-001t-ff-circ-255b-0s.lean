import Smt
import Smt.ZMod
import Mathlib.Data.ZMod.Basic
set_option maxRecDepth 2000000000000000000000

syntax "smt_unsat" : tactic

macro_rules
  | `(tactic| smt_unsat) => `(tactic| first | smt; trace "unsat")

abbrev my_prime := 52435875175126190479447740508185965837690552500527637822603658699938581184513

theorem compilation_sound_random_10v_001t_ff_circ_255b_0s [Fact my_prime.Prime]
  (j : Bool) (i : Bool) (h : Bool) (g : Bool) (f : Bool) (e : Bool) (d : Bool) (c : Bool) (b : Bool) (a : Bool) (return_n7 : ZMod my_prime) (j_n3 : ZMod my_prime) (c_n6 : ZMod my_prime) (g_n9 : ZMod my_prime) (e_n2 : ZMod my_prime) (i_n5 : ZMod my_prime) (h_n8 : ZMod my_prime) (f_n1 : ZMod my_prime) (d_n4 : ZMod my_prime) (a_n10 : ZMod my_prime) (b_n0 : ZMod my_prime) (is_zero_inv_n11 : ZMod my_prime) :
  (!((let let0 := j; (let let1 := i; (let let2 := h; (let let3 := g; (let let4 := f; (let let5 := e; (let let6 := d; (let let7 := c; (let let8 := b; (let let9 := a; (let let10 := (((((((((let9 || let8) || let7) || let6) || let5) || let4) || let3) || let2) || let1) || let0); (let let11 := return_n7; (let let12 := (1 : ZMod my_prime); (let let13 := (decide ((let12) = (let11))); (let let14 := (decide ((let13) = (let10))); (let let15 := (0 : ZMod my_prime); (let let16 := (decide ((let15) = (let11))); (let let17 := (let13 || let16); (let let18 := (let17 && let14); (let let19 := j_n3; (let let20 := c_n6; (let let21 := g_n9; (let let22 := e_n2; (let let23 := i_n5; (let let24 := h_n8; (let let25 := f_n1; (let let26 := d_n4; (let let27 := a_n10; (let let28 := b_n0; (let let29 := (((((((((let28 + let27) + let26) + let25) + let24) + let23) + let22) + let21) + let20) + let19); (let let30 := is_zero_inv_n11; (let let31 := (let30 * let29); (let let32 := (decide ((let31) = (let11))); (let let33 := (if (let5) then let12 else let15); (let let34 := (decide ((let22) = (let33))); (let let35 := (if (let8) then let12 else let15); (let let36 := (decide ((let28) = (let35))); (let let37 := (if (let6) then let12 else let15); (let let38 := (decide ((let26) = (let37))); (let let39 := (if (let1) then let12 else let15); (let let40 := (decide ((let23) = (let39))); (let let41 := (if (let3) then let12 else let15); (let let42 := (decide ((let21) = (let41))); (let let43 := (if (let9) then let12 else let15); (let let44 := (decide ((let27) = (let43))); (let let45 := (if (let2) then let12 else let15); (let let46 := (decide ((let24) = (let45))); (let let47 := (if (let4) then let12 else let15); (let let48 := (decide ((let25) = (let47))); (let let49 := (if (let7) then let12 else let15); (let let50 := (decide ((let20) = (let49))); (let let51 := (if (let0) then let12 else let15); (let let52 := (decide ((let19) = (let51))); (let let53 := (((((((((let52 && let50) && let48) && let46) && let44) && let42) && let40) && let38) && let36) && let34); (let let54 := (let53 && let32); (let let55 := (!(let54) || let18); (let let56 := !(let55); let56))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) = true := by
  unfold my_prime at *
  smt_unsat
