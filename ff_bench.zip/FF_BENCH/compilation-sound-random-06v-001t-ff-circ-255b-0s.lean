import Smt
import Smt.ZMod
import Mathlib.Data.ZMod.Basic
set_option maxRecDepth 2000000000000000000000

syntax "smt_unsat" : tactic

macro_rules
  | `(tactic| smt_unsat) => `(tactic| first | smt; trace "unsat")

abbrev my_prime := 52435875175126190479447740508185965837690552500527637822603658699938581184513

theorem compilation_sound_random_06v_001t_ff_circ_255b_0s [Fact my_prime.Prime]
  (f : Bool) (e : Bool) (d : Bool) (c : Bool) (b : Bool) (a : Bool) (return_n3 : ZMod my_prime) (a_n6 : ZMod my_prime) (d_n1 : ZMod my_prime) (f_n4 : ZMod my_prime) (c_n2 : ZMod my_prime) (b_n5 : ZMod my_prime) (e_n0 : ZMod my_prime) (is_zero_inv_n7 : ZMod my_prime) :
  (!((let let0 := f; (let let1 := e; (let let2 := d; (let let3 := c; (let let4 := b; (let let5 := a; (let let6 := (((((let5 && let4) && let3) && let2) && let1) && let0); (let let7 := return_n3; (let let8 := (1 : ZMod my_prime); (let let9 := (decide ((let8) = (let7))); (let let10 := (decide ((let9) = (let6))); (let let11 := (0 : ZMod my_prime); (let let12 := (decide ((let11) = (let7))); (let let13 := (let9 || let12); (let let14 := (let13 && let10); (let let15 := (52435875175126190479447740508185965837690552500527637822603658699938581184512 : ZMod my_prime); (let let16 := (let7 * let15); (let let17 := (let16 + let8); (let let18 := (6 : ZMod my_prime); (let let19 := a_n6; (let let20 := (let19 * let15); (let let21 := d_n1; (let let22 := (let21 * let15); (let let23 := f_n4; (let let24 := (let23 * let15); (let let25 := c_n2; (let let26 := (let25 * let15); (let let27 := b_n5; (let let28 := (let27 * let15); (let let29 := e_n0; (let let30 := (let29 * let15); (let let31 := ((((((let30 + let28) + let26) + let24) + let22) + let20) + let18); (let let32 := is_zero_inv_n7; (let let33 := (let32 * let31); (let let34 := (decide ((let33) = (let17))); (let let35 := (if (let1) then let8 else let11); (let let36 := (decide ((let29) = (let35))); (let let37 := (if (let4) then let8 else let11); (let let38 := (decide ((let27) = (let37))); (let let39 := (if (let2) then let8 else let11); (let let40 := (decide ((let21) = (let39))); (let let41 := (if (let5) then let8 else let11); (let let42 := (decide ((let19) = (let41))); (let let43 := (if (let3) then let8 else let11); (let let44 := (decide ((let25) = (let43))); (let let45 := (if (let0) then let8 else let11); (let let46 := (decide ((let23) = (let45))); (let let47 := (((((let46 && let44) && let42) && let40) && let38) && let36); (let let48 := (let47 && let34); (let let49 := (!(let48) || let14); (let let50 := !(let49); let50))))))))))))))))))))))))))))))))))))))))))))))))))))) = true := by
  unfold my_prime at *
  smt_unsat
