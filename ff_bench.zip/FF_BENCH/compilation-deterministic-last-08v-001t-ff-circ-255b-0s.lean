import Smt
import Smt.ZMod
import Mathlib.Data.ZMod.Basic
set_option maxRecDepth 2000000000000000000000

syntax "smt_unsat" : tactic

macro_rules
  | `(tactic| smt_unsat) => `(tactic| first | smt; trace "unsat")

abbrev my_prime := 52435875175126190479447740508185965837690552500527637822603658699938581184513

theorem compilation_deterministic_last_08v_001t_ff_circ_255b_0s [Fact my_prime.Prime]
  (return_n5_alt : ZMod my_prime) (d_n3_alt : ZMod my_prime) (h_n6_alt : ZMod my_prime) (e_n2_alt : ZMod my_prime) (a_n8_alt : ZMod my_prime) (f_n1_alt : ZMod my_prime) (c_n4_alt : ZMod my_prime) (g_n7_alt : ZMod my_prime) (b_n0_alt : ZMod my_prime) (is_zero_inv_n9_alt : ZMod my_prime) (return_n5 : ZMod my_prime) (d_n3 : ZMod my_prime) (h_n6 : ZMod my_prime) (e_n2 : ZMod my_prime) (a_n8 : ZMod my_prime) (f_n1 : ZMod my_prime) (c_n4 : ZMod my_prime) (g_n7 : ZMod my_prime) (b_n0 : ZMod my_prime) (is_zero_inv_n9 : ZMod my_prime) :
  (!((let let0 := return_n5_alt; (let let1 := d_n3_alt; (let let2 := h_n6_alt; (let let3 := e_n2_alt; (let let4 := a_n8_alt; (let let5 := f_n1_alt; (let let6 := c_n4_alt; (let let7 := g_n7_alt; (let let8 := b_n0_alt; (let let9 := (((((((let8 + let7) + let6) + let5) + let4) + let3) + let2) + let1); (let let10 := is_zero_inv_n9_alt; (let let11 := (let10 * let9); (let let12 := (decide ((let11) = (let0))); (let let13 := return_n5; (let let14 := d_n3; (let let15 := h_n6; (let let16 := e_n2; (let let17 := a_n8; (let let18 := f_n1; (let let19 := c_n4; (let let20 := g_n7; (let let21 := b_n0; (let let22 := (((((((let21 + let20) + let19) + let18) + let17) + let16) + let15) + let14); (let let23 := is_zero_inv_n9; (let let24 := (let23 * let22); (let let25 := (decide ((let24) = (let13))); (let let26 := (decide ((let13) = (let0))); (let let27 := !(let26); (let let28 := (decide ((let20) = (let7))); (let let29 := (decide ((let17) = (let4))); (let let30 := (decide ((let15) = (let2))); (let let31 := (decide ((let21) = (let8))); (let let32 := (decide ((let16) = (let3))); (let let33 := (decide ((let14) = (let1))); (let let34 := (decide ((let18) = (let5))); (let let35 := (decide ((let19) = (let6))); (let let36 := (((((((let35 && let34) && let33) && let32) && let31) && let30) && let29) && let28); (let let37 := (((let36 && let27) && let25) && let12); let37)))))))))))))))))))))))))))))))))))))))) = true := by
  unfold my_prime at *
  smt_unsat
