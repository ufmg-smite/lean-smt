import Smt
import Smt.ZMod
import Mathlib.Data.ZMod.Basic
set_option maxRecDepth 2000000000000000000000

syntax "smt_unsat" : tactic

macro_rules
  | `(tactic| smt_unsat) => `(tactic| first | smt; trace "unsat")

abbrev my_prime := 52435875175126190479447740508185965837690552500527637822603658699938581184513

theorem compilation_sound_last_04v_002t_ff_zokref_255b_0s [Fact my_prime.Prime]
  (a : Bool) (d : Bool) (c : Bool) (b : Bool) (out : ZMod my_prime) (_7 : ZMod my_prime) (_0 : ZMod my_prime) (_6 : ZMod my_prime) (_3 : ZMod my_prime) (_5 : ZMod my_prime) (_2 : ZMod my_prime) (_1 : ZMod my_prime) :
  (!((let let0 := a; (let let1 := !(let0); (let let2 := d; (let let3 := c; (let let4 := b; (let let5 := (((let4 && let3) && let2) && let1); (let let6 := out; (let let7 := (1 : ZMod my_prime); (let let8 := (decide ((let7) = (let6))); (let let9 := (decide ((let8) = (let5))); (let let10 := (0 : ZMod my_prime); (let let11 := (decide ((let10) = (let6))); (let let12 := (let8 || let11); (let let13 := (let12 && let9); (let let14 := _7; (let let15 := (52435875175126190479447740508185965837690552500527637822603658699938581184512 : ZMod my_prime); (let let16 := _0; (let let17 := (let16 * let15); (let let18 := (let17 + let7); (let let19 := _6; (let let20 := (let19 * let18); (let let21 := (decide ((let20) = (let14))); (let let22 := _3; (let let23 := _5; (let let24 := (let23 * let22); (let let25 := (decide ((let24) = (let19))); (let let26 := _2; (let let27 := _1; (let let28 := (let27 * let26); (let let29 := (decide ((let28) = (let23))); (let let30 := (let22 * let22); (let let31 := (decide ((let30) = (let22))); (let let32 := (let26 * let26); (let let33 := (decide ((let32) = (let26))); (let let34 := (let27 * let27); (let let35 := (decide ((let34) = (let27))); (let let36 := (let16 * let16); (let let37 := (decide ((let36) = (let16))); (let let38 := ((((((let37 && let35) && let33) && let31) && let29) && let25) && let21); (let let39 := (if (let0) then let7 else let10); (let let40 := (decide ((let16) = (let39))); (let let41 := (if (let3) then let7 else let10); (let let42 := (decide ((let26) = (let41))); (let let43 := (if (let4) then let7 else let10); (let let44 := (decide ((let27) = (let43))); (let let45 := (if (let2) then let7 else let10); (let let46 := (decide ((let22) = (let45))); (let let47 := (((let46 && let44) && let42) && let40); (let let48 := (let47 && let38); (let let49 := (!(let48) || let13); (let let50 := !(let49); let50))))))))))))))))))))))))))))))))))))))))))))))))))))) = true := by
  unfold my_prime at *
  smt_unsat
