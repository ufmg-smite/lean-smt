import Smt
import Smt.ZMod
import Mathlib.Data.ZMod.Basic
set_option maxRecDepth 2000000000000000000000

syntax "smt_unsat" : tactic

macro_rules
  | `(tactic| smt_unsat) => `(tactic| first | smt; trace "unsat")

abbrev my_prime := 131

theorem compilation_deterministic_last_02v_004t_ff_zokref_8b_0s [Fact my_prime.Prime]
  (_6_alt : ZMod my_prime) (_5_alt : ZMod my_prime) (_0_alt : ZMod my_prime) (_4_alt : ZMod my_prime) (_3_alt : ZMod my_prime) (_1_alt : ZMod my_prime) (_2_alt : ZMod my_prime) (_6 : ZMod my_prime) (_5 : ZMod my_prime) (_0 : ZMod my_prime) (_4 : ZMod my_prime) (_3 : ZMod my_prime) (_1 : ZMod my_prime) (_2 : ZMod my_prime) (out_alt : ZMod my_prime) (out : ZMod my_prime) :
  (!((let let0 := _6_alt; (let let1 := _5_alt; (let let2 := (130 : ZMod my_prime); (let let3 := _0_alt; (let let4 := (let3 * let2); (let let5 := (let4 + let1); (let let6 := (let5 * let5); (let let7 := (decide ((let6) = (let0))); (let let8 := _4_alt; (let let9 := (let8 * let3); (let let10 := (decide ((let9) = (let1))); (let let11 := _3_alt; (let let12 := (let11 * let3); (let let13 := (decide ((let12) = (let8))); (let let14 := _1_alt; (let let15 := _2_alt; (let let16 := (let15 * let14); (let let17 := (decide ((let16) = (let11))); (let let18 := (let14 * let3); (let let19 := (decide ((let18) = (let15))); (let let20 := (let14 * let14); (let let21 := (decide ((let20) = (let14))); (let let22 := (let3 * let3); (let let23 := (decide ((let22) = (let3))); (let let24 := ((((((let23 && let21) && let19) && let17) && let13) && let10) && let7); (let let25 := _6; (let let26 := _5; (let let27 := _0; (let let28 := (let27 * let2); (let let29 := (let28 + let26); (let let30 := (let29 * let29); (let let31 := (decide ((let30) = (let25))); (let let32 := _4; (let let33 := (let32 * let27); (let let34 := (decide ((let33) = (let26))); (let let35 := _3; (let let36 := (let35 * let27); (let let37 := (decide ((let36) = (let32))); (let let38 := _1; (let let39 := _2; (let let40 := (let39 * let38); (let let41 := (decide ((let40) = (let35))); (let let42 := (let38 * let27); (let let43 := (decide ((let42) = (let39))); (let let44 := (let38 * let38); (let let45 := (decide ((let44) = (let38))); (let let46 := (let27 * let27); (let let47 := (decide ((let46) = (let27))); (let let48 := ((((((let47 && let45) && let43) && let41) && let37) && let34) && let31); (let let49 := out_alt; (let let50 := out; (let let51 := (decide ((let50) = (let49))); (let let52 := !(let51); (let let53 := (decide ((let27) = (let3))); (let let54 := (decide ((let38) = (let14))); (let let55 := (let54 && let53); (let let56 := (((let55 && let52) && let48) && let24); let56))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) = true := by
  unfold my_prime at *
  smt_unsat
