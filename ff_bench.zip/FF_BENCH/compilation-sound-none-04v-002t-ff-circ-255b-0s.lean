import Smt
import Smt.ZMod
import Mathlib.Data.ZMod.Basic

abbrev k := 52435875175126190479447740508185965837690552500527637822603658699938581184513

theorem compilation_sound_none_04v_002t_ff_circ_255b_0s [Fact k.Prime]
  (return_n2 : ZMod k) (b_n3 : ZMod k) (c_n1 : ZMod k) (a_n4 : ZMod k) (d_n0 : ZMod k) (is_zero_inv_n5 : ZMod k) :
  (let let0 := a; (let let1 := (¬ (let0)); (let let2 := d; (let let3 := c; (let let4 := b; (let let5 := (((let4 ∧ let3) ∧ let2) ∧ let1); (let let6 := return_n2; (let let7 := (1 : ZMod k); (let let8 := ((let7) = (let6)); (let let9 := ((let8) = (let5)); (let let10 := (0 : ZMod k); (let let11 := ((let10) = (let6)); (let let12 := (let8 ∨ let11); (let let13 := (let12 ∧ let9); (let let14 := (3 : ZMod k); (let let15 := (52435875175126190479447740508185965837690552500527637822603658699938581184512 : ZMod k); (let let16 := b_n3; (let let17 := (let16 * let15); (let let18 := c_n1; (let let19 := (let18 * let15); (let let20 := a_n4; (let let21 := d_n0; (let let22 := (let21 * let15); (let let23 := ((((let22 + let20) + let19) + let17) + let14); (let let24 := (let6 * let23); (let let25 := ((let24) = (let10)); (let let26 := (let6 * let15); (let let27 := (let26 + let7); (let let28 := is_zero_inv_n5; (let let29 := (let28 * let23); (let let30 := ((let29) = (let27)); (let let31 := (let30 ∧ let25); (let let32 := (if let2 then let7 else let10); (let let33 := ((let21) = (let32)); (let let34 := (if let3 then let7 else let10); (let let35 := ((let18) = (let34)); (let let36 := (if let4 then let7 else let10); (let let37 := ((let16) = (let36)); (let let38 := (if let0 then let7 else let10); (let let39 := ((let20) = (let38)); (let let40 := (((let39 ∧ let37) ∧ let35) ∧ let33); (let let41 := (let40 ∧ let31); (let let42 := ((let41) → (let13)); (let let43 := (¬ (let42)); let43)))))))))))))))))))))))))))))))))))))))))))) := by
  unfold k at *
  smt
