import Smt
import Smt.ZMod
import Mathlib.Data.ZMod.Basic
set_option maxRecDepth 2000000000000000000000

syntax "smt_unsat" : tactic

macro_rules
  | `(tactic| smt_unsat) => `(tactic| first | smt; trace "unsat")

abbrev my_prime := 521

theorem compilation_sound_none_02v_004t_ff_circ_10b_0s [Fact my_prime.Prime]
  (a : Bool) (b : Bool) (return_n0 : ZMod my_prime) (mul_n3 : ZMod my_prime) (a_n2 : ZMod my_prime) (mul_n4 : ZMod my_prime) (b_n1 : ZMod my_prime) :
  (!((let let0 := a; (let let1 := b; (let let2 := (!(let1) || let0); (let let3 := !(let2); (let let4 := (if (let2) then let1 else let0); (let let5 := (let4 && let3); (let let6 := return_n0; (let let7 := (1 : ZMod my_prime); (let let8 := (decide ((let7) = (let6))); (let let9 := (decide ((let8) = (let5))); (let let10 := (0 : ZMod my_prime); (let let11 := (decide ((let10) = (let6))); (let let12 := (let8 || let11); (let let13 := (let12 && let9); (let let14 := mul_n3; (let let15 := a_n2; (let let16 := mul_n4; (let let17 := (let16 + let15); (let let18 := (let17 * let14); (let let19 := (decide ((let18) = (let6))); (let let20 := (520 : ZMod my_prime); (let let21 := (let15 * let20); (let let22 := b_n1; (let let23 := (let22 + let21); (let let24 := (let14 * let20); (let let25 := (let24 + let7); (let let26 := (let25 * let23); (let let27 := (decide ((let26) = (let16))); (let let28 := (let21 + let7); (let let29 := (let22 * let28); (let let30 := (decide ((let29) = (let14))); (let let31 := ((let30 && let27) && let19); (let let32 := (if (let1) then let7 else let10); (let let33 := (decide ((let22) = (let32))); (let let34 := (if (let0) then let7 else let10); (let let35 := (decide ((let15) = (let34))); (let let36 := (let35 && let33); (let let37 := (let36 && let31); (let let38 := (!(let37) || let13); (let let39 := !(let38); let39)))))))))))))))))))))))))))))))))))))))))) = true := by
  unfold my_prime at *
  smt_unsat
