import Smt
import Smt.ZMod
import Mathlib.Data.ZMod.Basic
set_option maxRecDepth 2000000000000000000000

syntax "smt_unsat" : tactic

macro_rules
  | `(tactic| smt_unsat) => `(tactic| first | smt; trace "unsat")

abbrev my_prime := 1031

theorem compilation_sound_last_02v_004t_ff_zokref_11b_0s [Fact my_prime.Prime]
  (a : Bool) (b : Bool) (out : ZMod my_prime) (_10 : ZMod my_prime) (_2 : ZMod my_prime) (_8 : ZMod my_prime) (_7 : ZMod my_prime) (_0 : ZMod my_prime) (_1 : ZMod my_prime) :
  (!((let let0 := a; (let let1 := b; (let let2 := (!(let1) || let0); (let let3 := !(let2); (let let4 := (if (let2) then let1 else let0); (let let5 := (let4 && let3); (let let6 := out; (let let7 := (1 : ZMod my_prime); (let let8 := (decide ((let7) = (let6))); (let let9 := (decide ((let8) = (let5))); (let let10 := (0 : ZMod my_prime); (let let11 := (decide ((let10) = (let6))); (let let12 := (let8 || let11); (let let13 := (let12 && let9); (let let14 := _10; (let let15 := (1030 : ZMod my_prime); (let let16 := _2; (let let17 := (let16 * let15); (let let18 := (let17 + let7); (let let19 := _8; (let let20 := _7; (let let21 := (let20 + let19); (let let22 := (let21 * let18); (let let23 := (decide ((let22) = (let14))); (let let24 := _0; (let let25 := (let18 * let24); (let let26 := (decide ((let25) = (let19))); (let let27 := _1; (let let28 := (let16 * let27); (let let29 := (decide ((let28) = (let20))); (let let30 := (let27 * let15); (let let31 := (((let24 + let30) + let17) + let7); (let let32 := (let30 + let7); (let let33 := (let32 * let24); (let let34 := (decide ((let33) = (let31))); (let let35 := (let27 * let27); (let let36 := (decide ((let35) = (let27))); (let let37 := (let24 * let24); (let let38 := (decide ((let37) = (let24))); (let let39 := (((((let38 && let36) && let34) && let29) && let26) && let23); (let let40 := (if (let0) then let7 else let10); (let let41 := (decide ((let24) = (let40))); (let let42 := (if (let1) then let7 else let10); (let let43 := (decide ((let27) = (let42))); (let let44 := (let43 && let41); (let let45 := (let44 && let39); (let let46 := (!(let45) || let13); (let let47 := !(let46); let47)))))))))))))))))))))))))))))))))))))))))))))))))) = true := by
  unfold my_prime at *
  smt_unsat
