import Smt
import Smt.ZMod
import Mathlib.Data.ZMod.Basic
set_option maxRecDepth 2000000000000000000000

syntax "smt_unsat" : tactic

macro_rules
  | `(tactic| smt_unsat) => `(tactic| first | smt; trace "unsat")

abbrev my_prime := 52435875175126190479447740508185965837690552500527637822603658699938581184513

theorem compilation_deterministic_none_08v_001t_ff_circ_255b_0s [Fact my_prime.Prime]
  (d_n3_alt : ZMod my_prime) (h_n6_alt : ZMod my_prime) (e_n2_alt : ZMod my_prime) (a_n8_alt : ZMod my_prime) (f_n1_alt : ZMod my_prime) (c_n4_alt : ZMod my_prime) (g_n7_alt : ZMod my_prime) (b_n0_alt : ZMod my_prime) (return_n5_alt : ZMod my_prime) (is_zero_inv_n9_alt : ZMod my_prime) (d_n3 : ZMod my_prime) (h_n6 : ZMod my_prime) (e_n2 : ZMod my_prime) (a_n8 : ZMod my_prime) (f_n1 : ZMod my_prime) (c_n4 : ZMod my_prime) (g_n7 : ZMod my_prime) (b_n0 : ZMod my_prime) (return_n5 : ZMod my_prime) (is_zero_inv_n9 : ZMod my_prime) :
  (!((let let0 := (0 : ZMod my_prime); (let let1 := d_n3_alt; (let let2 := h_n6_alt; (let let3 := e_n2_alt; (let let4 := a_n8_alt; (let let5 := f_n1_alt; (let let6 := c_n4_alt; (let let7 := g_n7_alt; (let let8 := b_n0_alt; (let let9 := (((((((let8 + let7) + let6) + let5) + let4) + let3) + let2) + let1); (let let10 := (1 : ZMod my_prime); (let let11 := (52435875175126190479447740508185965837690552500527637822603658699938581184512 : ZMod my_prime); (let let12 := return_n5_alt; (let let13 := (let12 * let11); (let let14 := (let13 + let10); (let let15 := (let14 * let9); (let let16 := (decide ((let15) = (let0))); (let let17 := is_zero_inv_n9_alt; (let let18 := (let17 * let9); (let let19 := (decide ((let18) = (let12))); (let let20 := (let19 && let16); (let let21 := d_n3; (let let22 := h_n6; (let let23 := e_n2; (let let24 := a_n8; (let let25 := f_n1; (let let26 := c_n4; (let let27 := g_n7; (let let28 := b_n0; (let let29 := (((((((let28 + let27) + let26) + let25) + let24) + let23) + let22) + let21); (let let30 := return_n5; (let let31 := (let30 * let11); (let let32 := (let31 + let10); (let let33 := (let32 * let29); (let let34 := (decide ((let33) = (let0))); (let let35 := is_zero_inv_n9; (let let36 := (let35 * let29); (let let37 := (decide ((let36) = (let30))); (let let38 := (let37 && let34); (let let39 := (decide ((let30) = (let12))); (let let40 := !(let39); (let let41 := (decide ((let28) = (let8))); (let let42 := (decide ((let27) = (let7))); (let let43 := (decide ((let26) = (let6))); (let let44 := (decide ((let23) = (let3))); (let let45 := (decide ((let25) = (let5))); (let let46 := (decide ((let21) = (let1))); (let let47 := (decide ((let22) = (let2))); (let let48 := (decide ((let24) = (let4))); (let let49 := (((((((let48 && let47) && let46) && let45) && let44) && let43) && let42) && let41); (let let50 := (((let49 && let40) && let38) && let20); let50))))))))))))))))))))))))))))))))))))))))))))))))))))) = true := by
  unfold my_prime at *
  smt_unsat
