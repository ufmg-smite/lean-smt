import Smt
import Smt.ZMod
import Mathlib.Data.ZMod.Basic
set_option maxRecDepth 2000000000000000000000

syntax "smt_unsat" : tactic

macro_rules
  | `(tactic| smt_unsat) => `(tactic| first | smt; trace "unsat")

abbrev my_prime := 52435875175126190479447740508185965837690552500527637822603658699938581184513

theorem compilation_sound_last_06v_002t_ff_zokcirc_255b_0s [Fact my_prime.Prime]
  (c : Bool) (b : Bool) (d : Bool) (f : Bool) (e : Bool) (a : Bool) (return_n3 : ZMod my_prime) (mul_n9 : ZMod my_prime) (f_n5 : ZMod my_prime) (mul_n8 : ZMod my_prime) (e_n0 : ZMod my_prime) (a_n6 : ZMod my_prime) (mul_n7 : ZMod my_prime) (c_n2 : ZMod my_prime) (b_n4 : ZMod my_prime) (d_n1 : ZMod my_prime) :
  (!((let let0 := c; (let let1 := b; (let let2 := d; (let let3 := (if (let2) then let1 else let0); (let let4 := f; (let let5 := e; (let let6 := a; (let let7 := (((let6 || let5) || let4) || let3); (let let8 := return_n3; (let let9 := (1 : ZMod my_prime); (let let10 := (decide ((let9) = (let8))); (let let11 := (decide ((let10) = (let7))); (let let12 := (0 : ZMod my_prime); (let let13 := (decide ((let12) = (let8))); (let let14 := (let10 || let13); (let let15 := (let14 && let11); (let let16 := mul_n9; (let let17 := (52435875175126190479447740508185965837690552500527637822603658699938581184512 : ZMod my_prime); (let let18 := f_n5; (let let19 := (let18 * let17); (let let20 := (let19 + let9); (let let21 := mul_n8; (let let22 := (let21 * let20); (let let23 := (decide ((let22) = (let16))); (let let24 := e_n0; (let let25 := (let24 * let17); (let let26 := (let25 + let9); (let let27 := a_n6; (let let28 := (let27 * let17); (let let29 := (let28 + let9); (let let30 := (let29 * let26); (let let31 := (decide ((let30) = (let21))); (let let32 := mul_n7; (let let33 := c_n2; (let let34 := (let33 * let17); (let let35 := b_n4; (let let36 := (let35 + let34); (let let37 := d_n1; (let let38 := (let37 * let36); (let let39 := (decide ((let38) = (let32))); (let let40 := ((let39 && let31) && let23); (let let41 := (if (let0) then let9 else let12); (let let42 := (decide ((let33) = (let41))); (let let43 := (if (let5) then let9 else let12); (let let44 := (decide ((let24) = (let43))); (let let45 := (if (let4) then let9 else let12); (let let46 := (decide ((let18) = (let45))); (let let47 := (if (let1) then let9 else let12); (let let48 := (decide ((let35) = (let47))); (let let49 := (if (let6) then let9 else let12); (let let50 := (decide ((let27) = (let49))); (let let51 := (if (let2) then let9 else let12); (let let52 := (decide ((let37) = (let51))); (let let53 := (((((let52 && let50) && let48) && let46) && let44) && let42); (let let54 := (let53 && let40); (let let55 := (!(let54) || let15); (let let56 := !(let55); let56))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) = true := by
  unfold my_prime at *
  smt_unsat
