import Smt
import Smt.ZMod
import Mathlib.Data.ZMod.Basic
set_option maxRecDepth 2000000000000000000000

syntax "smt_unsat" : tactic

macro_rules
  | `(tactic| smt_unsat) => `(tactic| first | smt; trace "unsat")

abbrev my_prime := 52435875175126190479447740508185965837690552500527637822603658699938581184513

theorem compilation_sound_random_08v_002t_ff_circ_255b_0s [Fact my_prime.Prime]
  (e : Bool) (d : Bool) (h : Bool) (g : Bool) (f : Bool) (c : Bool) (b : Bool) (a : Bool) (return_n5 : ZMod my_prime) (d_n3 : ZMod my_prime) (h_n6 : ZMod my_prime) (mul_n9 : ZMod my_prime) (e_n2 : ZMod my_prime) (a_n8 : ZMod my_prime) (f_n1 : ZMod my_prime) (c_n4 : ZMod my_prime) (g_n7 : ZMod my_prime) (b_n0 : ZMod my_prime) :
  (!((let let0 := e; (let let1 := d; (let let2 := (decide ((let1) = (let0))); (let let3 := h; (let let4 := g; (let let5 := f; (let let6 := c; (let let7 := b; (let let8 := a; (let let9 := ((((((let8 && let7) && let6) && let5) && let4) && let3) && let2); (let let10 := return_n5; (let let11 := (1 : ZMod my_prime); (let let12 := (decide ((let11) = (let10))); (let let13 := (decide ((let12) = (let9))); (let let14 := (0 : ZMod my_prime); (let let15 := (decide ((let14) = (let10))); (let let16 := (let12 || let15); (let let17 := (let16 && let13); (let let18 := (6 : ZMod my_prime); (let let19 := d_n3; (let let20 := (52435875175126190479447740508185965837690552500527637822603658699938581184512 : ZMod my_prime); (let let21 := h_n6; (let let22 := (let21 * let20); (let let23 := mul_n9; (let let24 := (let23 * let20); (let let25 := e_n2; (let let26 := a_n8; (let let27 := (let26 * let20); (let let28 := f_n1; (let let29 := (let28 * let20); (let let30 := c_n4; (let let31 := (let30 * let20); (let let32 := g_n7; (let let33 := (let32 * let20); (let let34 := b_n0; (let let35 := (let34 * let20); (let let36 := (((((((((let35 + let33) + let31) + let29) + let27) + let25) + let24) + let22) + let19) + let18); (let let37 := (let10 * let36); (let let38 := (decide ((let37) = (let14))); (let let39 := (2 : ZMod my_prime); (let let40 := (let19 * let39); (let let41 := (let40 * let25); (let let42 := (decide ((let41) = (let23))); (let let43 := (let42 && let38); (let let44 := (if (let5) then let11 else let14); (let let45 := (decide ((let28) = (let44))); (let let46 := (if (let3) then let11 else let14); (let let47 := (decide ((let21) = (let46))); (let let48 := (if (let6) then let11 else let14); (let let49 := (decide ((let30) = (let48))); (let let50 := (if (let1) then let11 else let14); (let let51 := (decide ((let19) = (let50))); (let let52 := (if (let4) then let11 else let14); (let let53 := (decide ((let32) = (let52))); (let let54 := (if (let7) then let11 else let14); (let let55 := (decide ((let34) = (let54))); (let let56 := (if (let0) then let11 else let14); (let let57 := (decide ((let25) = (let56))); (let let58 := (if (let8) then let11 else let14); (let let59 := (decide ((let26) = (let58))); (let let60 := (((((((let59 && let57) && let55) && let53) && let51) && let49) && let47) && let45); (let let61 := (let60 && let43); (let let62 := (!(let61) || let17); (let let63 := !(let62); let63)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) = true := by
  unfold my_prime at *
  smt_unsat
