import Smt
import Smt.ZMod
import Mathlib.Data.ZMod.Basic

abbrev k := 52435875175126190479447740508185965837690552500527637822603658699938581184513

theorem compilation_sound_last_02v_001t_ff_zokcirc_255b_0s [Fact k.Prime]
  (return_n0 : ZMod k) (b_n1 : ZMod k) (a_n2 : ZMod k) :
  (let let0 := b; (let let1 := a; (let let2 := (let1 ∧ let0); (let let3 := return_n0; (let let4 := (1 : ZMod k); (let let5 := ((let4) = (let3)); (let let6 := ((let5) = (let2)); (let let7 := (0 : ZMod k); (let let8 := ((let7) = (let3)); (let let9 := (let5 ∨ let8); (let let10 := (let9 ∧ let6); (let let11 := b_n1; (let let12 := a_n2; (let let13 := (let12 * let11); (let let14 := ((let13) = (let3)); (let let15 := (if let0 then let4 else let7); (let let16 := ((let11) = (let15)); (let let17 := (if let1 then let4 else let7); (let let18 := ((let12) = (let17)); (let let19 := (let18 ∧ let16); (let let20 := (let19 ∧ let14); (let let21 := ((let20) → (let10)); (let let22 := (¬ (let21)); let22))))))))))))))))))))))) := by
  unfold k at *
  smt
