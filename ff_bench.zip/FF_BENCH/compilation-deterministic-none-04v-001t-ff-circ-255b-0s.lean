import Smt
import Smt.ZMod
import Mathlib.Data.ZMod.Basic
set_option maxRecDepth 2000000000000000000000

syntax "smt_unsat" : tactic

macro_rules
  | `(tactic| smt_unsat) => `(tactic| first | smt; trace "unsat")

abbrev my_prime := 52435875175126190479447740508185965837690552500527637822603658699938581184513

theorem compilation_deterministic_none_04v_001t_ff_circ_255b_0s [Fact my_prime.Prime]
  (b_n3_alt : ZMod my_prime) (c_n1_alt : ZMod my_prime) (a_n4_alt : ZMod my_prime) (d_n0_alt : ZMod my_prime) (return_n2_alt : ZMod my_prime) (is_zero_inv_n5_alt : ZMod my_prime) (b_n3 : ZMod my_prime) (c_n1 : ZMod my_prime) (a_n4 : ZMod my_prime) (d_n0 : ZMod my_prime) (return_n2 : ZMod my_prime) (is_zero_inv_n5 : ZMod my_prime) :
  (!((let let0 := (0 : ZMod my_prime); (let let1 := (4 : ZMod my_prime); (let let2 := (52435875175126190479447740508185965837690552500527637822603658699938581184512 : ZMod my_prime); (let let3 := b_n3_alt; (let let4 := (let3 * let2); (let let5 := c_n1_alt; (let let6 := (let5 * let2); (let let7 := a_n4_alt; (let let8 := (let7 * let2); (let let9 := d_n0_alt; (let let10 := (let9 * let2); (let let11 := ((((let10 + let8) + let6) + let4) + let1); (let let12 := return_n2_alt; (let let13 := (let12 * let11); (let let14 := (decide ((let13) = (let0))); (let let15 := (1 : ZMod my_prime); (let let16 := (let12 * let2); (let let17 := (let16 + let15); (let let18 := is_zero_inv_n5_alt; (let let19 := (let18 * let11); (let let20 := (decide ((let19) = (let17))); (let let21 := (let20 && let14); (let let22 := b_n3; (let let23 := (let22 * let2); (let let24 := c_n1; (let let25 := (let24 * let2); (let let26 := a_n4; (let let27 := (let26 * let2); (let let28 := d_n0; (let let29 := (let28 * let2); (let let30 := ((((let29 + let27) + let25) + let23) + let1); (let let31 := return_n2; (let let32 := (let31 * let30); (let let33 := (decide ((let32) = (let0))); (let let34 := (let31 * let2); (let let35 := (let34 + let15); (let let36 := is_zero_inv_n5; (let let37 := (let36 * let30); (let let38 := (decide ((let37) = (let35))); (let let39 := (let38 && let33); (let let40 := (decide ((let31) = (let12))); (let let41 := !(let40); (let let42 := (decide ((let24) = (let5))); (let let43 := (decide ((let22) = (let3))); (let let44 := (decide ((let28) = (let9))); (let let45 := (decide ((let26) = (let7))); (let let46 := (((let45 && let44) && let43) && let42); (let let47 := (((let46 && let41) && let39) && let21); let47)))))))))))))))))))))))))))))))))))))))))))))))))) = true := by
  unfold my_prime at *
  smt_unsat
