import Smt
import Smt.ZMod
import Mathlib.Data.ZMod.Basic
set_option maxRecDepth 2000000000000000000000

syntax "smt_unsat" : tactic

macro_rules
  | `(tactic| smt_unsat) => `(tactic| first | smt; trace "unsat")

abbrev my_prime := 52435875175126190479447740508185965837690552500527637822603658699938581184513

theorem compilation_sound_last_02v_008t_ff_zokcirc_255b_0s [Fact my_prime.Prime]
  (a : Bool) (b : Bool) (return_n0 : ZMod my_prime) (mul_n7 : ZMod my_prime) (mul_n6 : ZMod my_prime) (b_n1 : ZMod my_prime) (mul_n4 : ZMod my_prime) (a_n2 : ZMod my_prime) (mul_n5 : ZMod my_prime) (mul_n3 : ZMod my_prime) :
  (!((let let0 := a; (let let1 := !(let0); (let let2 := !(let1); (let let3 := (decide ((let2) = (let0))); (let let4 := b; (let let5 := (decide ((let4) = (let4))); (let let6 := (decide ((let2) = (let4))); (let let7 := (if (let1) then let0 else let6); (let let8 := (if (let6) then let7 else let5); (let let9 := (let8 || let3); (let let10 := return_n0; (let let11 := (1 : ZMod my_prime); (let let12 := (decide ((let11) = (let10))); (let let13 := (decide ((let12) = (let9))); (let let14 := (0 : ZMod my_prime); (let let15 := (decide ((let14) = (let10))); (let let16 := (let12 || let15); (let let17 := (let16 && let13); (let let18 := mul_n7; (let let19 := mul_n6; (let let20 := b_n1; (let let21 := (52435875175126190479447740508185965837690552500527637822603658699938581184512 : ZMod my_prime); (let let22 := mul_n4; (let let23 := (let22 * let21); (let let24 := a_n2; (let let25 := (let24 * let21); (let let26 := mul_n5; (let let27 := ((((let26 + let25) + let23) + let20) + let19); (let let28 := (let20 * let21); (let let29 := (((let26 + let25) + let28) + let11); (let let30 := (let29 * let27); (let let31 := (decide ((let30) = (let18))); (let let32 := (2 : ZMod my_prime); (let let33 := (let24 * let32); (let let34 := (let26 * let21); (let let35 := (((let34 + let33) + let20) + let21); (let let36 := (let25 + let11); (let let37 := (let36 * let35); (let let38 := (decide ((let37) = (let19))); (let let39 := (let33 * let20); (let let40 := (decide ((let39) = (let26))); (let let41 := (let20 * let32); (let let42 := (let41 * let20); (let let43 := (decide ((let42) = (let22))); (let let44 := mul_n3; (let let45 := (let33 * let24); (let let46 := (decide ((let45) = (let44))); (let let47 := ((((let46 && let43) && let40) && let38) && let31); (let let48 := (if (let4) then let11 else let14); (let let49 := (decide ((let20) = (let48))); (let let50 := (if (let0) then let11 else let14); (let let51 := (decide ((let24) = (let50))); (let let52 := (let51 && let49); (let let53 := (let52 && let47); (let let54 := (!(let53) || let17); (let let55 := !(let54); let55)))))))))))))))))))))))))))))))))))))))))))))))))))))))))) = true := by
  unfold my_prime at *
  smt_unsat
