import Smt
import Smt.ZMod
import Mathlib.Data.ZMod.Basic

abbrev k := 52435875175126190479447740508185965837690552500527637822603658699938581184513

theorem compilation_deterministic_last_04v_001t_ff_zokcirc_255b_0s [Fact k.Prime]
  (mul_n6_alt : ZMod k) (c_n1_alt : ZMod k) (mul_n5_alt : ZMod k) (b_n3_alt : ZMod k) (a_n4_alt : ZMod k) (mul_n6 : ZMod k) (c_n1 : ZMod k) (mul_n5 : ZMod k) (b_n3 : ZMod k) (a_n4 : ZMod k) (return_n2_alt : ZMod k) (return_n2 : ZMod k) (d_n0_alt : ZMod k) (d_n0 : ZMod k) :
  (let let0 := mul_n6_alt; (let let1 := c_n1_alt; (let let2 := mul_n5_alt; (let let3 := (let2 * let1); (let let4 := ((let3) = (let0)); (let let5 := b_n3_alt; (let let6 := a_n4_alt; (let let7 := (let6 * let5); (let let8 := ((let7) = (let2)); (let let9 := (let8 ∧ let4); (let let10 := mul_n6; (let let11 := c_n1; (let let12 := mul_n5; (let let13 := (let12 * let11); (let let14 := ((let13) = (let10)); (let let15 := b_n3; (let let16 := a_n4; (let let17 := (let16 * let15); (let let18 := ((let17) = (let12)); (let let19 := (let18 ∧ let14); (let let20 := return_n2_alt; (let let21 := return_n2; (let let22 := ((let21) = (let20)); (let let23 := (¬ (let22)); (let let24 := ((let15) = (let5)); (let let25 := ((let16) = (let6)); (let let26 := d_n0_alt; (let let27 := d_n0; (let let28 := ((let27) = (let26)); (let let29 := ((let11) = (let1)); (let let30 := (((let29 ∧ let28) ∧ let25) ∧ let24); (let let31 := (((let30 ∧ let23) ∧ let19) ∧ let9); let31)))))))))))))))))))))))))))))))) := by
  unfold k at *
  smt
