import Smt
import Smt.ZMod
import Mathlib.Data.ZMod.Basic

abbrev k := 52435875175126190479447740508185965837690552500527637822603658699938581184513

theorem compilation_sound_none_02v_004t_ff_zokref_255b_0s [Fact k.Prime]
  (out : ZMod k) (_10 : ZMod k) (_2 : ZMod k) (_8 : ZMod k) (_7 : ZMod k) (_0 : ZMod k) (_1 : ZMod k) :
  (let let0 := a; (let let1 := b; (let let2 := ((let1) → (let0)); (let let3 := (¬ (let2)); (let let4 := (if let2 then let1 else let0); (let let5 := (let4 ∧ let3); (let let6 := out; (let let7 := (1 : ZMod k); (let let8 := ((let7) = (let6)); (let let9 := ((let8) = (let5)); (let let10 := (0 : ZMod k); (let let11 := ((let10) = (let6)); (let let12 := (let8 ∨ let11); (let let13 := (let12 ∧ let9); (let let14 := _10; (let let15 := ((let14) = (let6)); (let let16 := (52435875175126190479447740508185965837690552500527637822603658699938581184512 : ZMod k); (let let17 := _2; (let let18 := (let17 * let16); (let let19 := (let18 + let7); (let let20 := _8; (let let21 := _7; (let let22 := (let21 + let20); (let let23 := (let22 * let19); (let let24 := ((let23) = (let14)); (let let25 := _0; (let let26 := (let19 * let25); (let let27 := ((let26) = (let20)); (let let28 := _1; (let let29 := (let17 * let28); (let let30 := ((let29) = (let21)); (let let31 := (let28 * let16); (let let32 := (((let25 + let31) + let18) + let7); (let let33 := (let31 + let7); (let let34 := (let33 * let25); (let let35 := ((let34) = (let32)); (let let36 := (let28 * let28); (let let37 := ((let36) = (let28)); (let let38 := (let25 * let25); (let let39 := ((let38) = (let25)); (let let40 := ((((((let39 ∧ let37) ∧ let35) ∧ let30) ∧ let27) ∧ let24) ∧ let15); (let let41 := (if let0 then let7 else let10); (let let42 := ((let25) = (let41)); (let let43 := (if let1 then let7 else let10); (let let44 := ((let28) = (let43)); (let let45 := (let44 ∧ let42); (let let46 := (let45 ∧ let40); (let let47 := ((let46) → (let13)); (let let48 := (¬ (let47)); let48))))))))))))))))))))))))))))))))))))))))))))))))) := by
  unfold k at *
  smt
