import Smt
import Smt.ZMod
import Mathlib.Data.ZMod.Basic

abbrev k := 52435875175126190479447740508185965837690552500527637822603658699938581184513

theorem compilation_deterministic_random_04v_002t_ff_circ_255b_0s [Fact k.Prime]
  (return_n2_alt : ZMod k) (b_n3_alt : ZMod k) (c_n1_alt : ZMod k) (a_n4_alt : ZMod k) (d_n0_alt : ZMod k) (is_zero_inv_n5_alt : ZMod k) (return_n2 : ZMod k) (b_n3 : ZMod k) (c_n1 : ZMod k) (a_n4 : ZMod k) (d_n0 : ZMod k) (is_zero_inv_n5 : ZMod k) :
  (let let0 := return_n2_alt; (let let1 := b_n3_alt; (let let2 := c_n1_alt; (let let3 := a_n4_alt; (let let4 := d_n0_alt; (let let5 := (((let4 + let3) + let2) + let1); (let let6 := is_zero_inv_n5_alt; (let let7 := (let6 * let5); (let let8 := ((let7) = (let0)); (let let9 := return_n2; (let let10 := b_n3; (let let11 := c_n1; (let let12 := a_n4; (let let13 := d_n0; (let let14 := (((let13 + let12) + let11) + let10); (let let15 := is_zero_inv_n5; (let let16 := (let15 * let14); (let let17 := ((let16) = (let9)); (let let18 := ((let9) = (let0)); (let let19 := (¬ (let18)); (let let20 := ((let13) = (let4)); (let let21 := ((let10) = (let1)); (let let22 := ((let12) = (let3)); (let let23 := ((let11) = (let2)); (let let24 := (((let23 ∧ let22) ∧ let21) ∧ let20); (let let25 := (((let24 ∧ let19) ∧ let17) ∧ let8); let25)))))))))))))))))))))))))) := by
  unfold k at *
  smt
