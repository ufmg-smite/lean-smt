import Smt
import Smt.ZMod
import Mathlib.Data.ZMod.Basic

abbrev k := 52435875175126190479447740508185965837690552500527637822603658699938581184513

theorem compilation_deterministic_none_02v_002t_ff_zokcirc_255b_0s [Fact k.Prime]
  (return_n0_alt : ZMod k) (b_n1_alt : ZMod k) (mul_n3_alt : ZMod k) (a_n2_alt : ZMod k) (return_n0 : ZMod k) (b_n1 : ZMod k) (mul_n3 : ZMod k) (a_n2 : ZMod k) :
  (let let0 := (1 : ZMod k); (let let1 := (52435875175126190479447740508185965837690552500527637822603658699938581184512 : ZMod k); (let let2 := return_n0_alt; (let let3 := (let2 * let1); (let let4 := (let3 + let0); (let let5 := b_n1_alt; (let let6 := (let5 * let1); (let let7 := (let6 + let0); (let let8 := mul_n3_alt; (let let9 := (let8 * let7); (let let10 := ((let9) = (let4)); (let let11 := a_n2_alt; (let let12 := (let11 * let1); (let let13 := (let12 + let0); (let let14 := (let13 * let7); (let let15 := ((let14) = (let8)); (let let16 := (let15 ∧ let10); (let let17 := return_n0; (let let18 := (let17 * let1); (let let19 := (let18 + let0); (let let20 := b_n1; (let let21 := (let20 * let1); (let let22 := (let21 + let0); (let let23 := mul_n3; (let let24 := (let23 * let22); (let let25 := ((let24) = (let19)); (let let26 := a_n2; (let let27 := (let26 * let1); (let let28 := (let27 + let0); (let let29 := (let28 * let22); (let let30 := ((let29) = (let23)); (let let31 := (let30 ∧ let25); (let let32 := ((let17) = (let2)); (let let33 := (¬ (let32)); (let let34 := ((let26) = (let11)); (let let35 := ((let20) = (let5)); (let let36 := (let35 ∧ let34); (let let37 := (((let36 ∧ let33) ∧ let31) ∧ let16); let37)))))))))))))))))))))))))))))))))))))) := by
  unfold k at *
  smt
