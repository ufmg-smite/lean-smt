import Smt
import Smt.ZMod
import Mathlib.Data.ZMod.Basic

abbrev k := 52435875175126190479447740508185965837690552500527637822603658699938581184513

theorem compilation_sound_random_06v_002t_ff_circ_255b_0s [Fact k.Prime]
  (return_n3 : ZMod k) (a_n6 : ZMod k) (mul_n7 : ZMod k) (c_n2 : ZMod k) (f_n5 : ZMod k) (e_n0 : ZMod k) (b_n4 : ZMod k) (d_n1 : ZMod k) :
  (let let0 := c; (let let1 := b; (let let2 := d; (let let3 := (if let2 then let1 else let0); (let let4 := f; (let let5 := e; (let let6 := a; (let let7 := (((let6 ∨ let5) ∨ let4) ∨ let3); (let let8 := return_n3; (let let9 := (1 : ZMod k); (let let10 := ((let9) = (let8)); (let let11 := ((let10) = (let7)); (let let12 := (0 : ZMod k); (let let13 := ((let12) = (let8)); (let let14 := (let10 ∨ let13); (let let15 := (let14 ∧ let11); (let let16 := a_n6; (let let17 := mul_n7; (let let18 := c_n2; (let let19 := f_n5; (let let20 := e_n0; (let let21 := ((((let20 + let19) + let18) + let17) + let16); (let let22 := (52435875175126190479447740508185965837690552500527637822603658699938581184512 : ZMod k); (let let23 := (let8 * let22); (let let24 := (let23 + let9); (let let25 := (let24 * let21); (let let26 := ((let25) = (let12)); (let let27 := (let18 * let22); (let let28 := b_n4; (let let29 := (let28 + let27); (let let30 := d_n1; (let let31 := (let30 * let29); (let let32 := ((let31) = (let17)); (let let33 := (let32 ∧ let26); (let let34 := (if let2 then let9 else let12); (let let35 := ((let30) = (let34)); (let let36 := (if let1 then let9 else let12); (let let37 := ((let28) = (let36)); (let let38 := (if let5 then let9 else let12); (let let39 := ((let20) = (let38)); (let let40 := (if let4 then let9 else let12); (let let41 := ((let19) = (let40)); (let let42 := (if let0 then let9 else let12); (let let43 := ((let18) = (let42)); (let let44 := (if let6 then let9 else let12); (let let45 := ((let16) = (let44)); (let let46 := (((((let45 ∧ let43) ∧ let41) ∧ let39) ∧ let37) ∧ let35); (let let47 := (let46 ∧ let33); (let let48 := ((let47) → (let15)); (let let49 := (¬ (let48)); let49)))))))))))))))))))))))))))))))))))))))))))))))))) := by
  unfold k at *
  smt
