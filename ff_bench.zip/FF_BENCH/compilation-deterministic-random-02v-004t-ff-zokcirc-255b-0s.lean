import Smt
import Smt.ZMod
import Mathlib.Data.ZMod.Basic

abbrev k := 52435875175126190479447740508185965837690552500527637822603658699938581184513

theorem compilation_deterministic_random_02v_004t_ff_zokcirc_255b_0s [Fact k.Prime]
  (mul_n6_alt : ZMod k) (a_n2_alt : ZMod k) (return_n0_alt : ZMod k) (mul_n5_alt : ZMod k) (mul_n4_alt : ZMod k) (b_n1_alt : ZMod k) (mul_n3_alt : ZMod k) (mul_n6 : ZMod k) (a_n2 : ZMod k) (return_n0 : ZMod k) (mul_n5 : ZMod k) (mul_n4 : ZMod k) (b_n1 : ZMod k) (mul_n3 : ZMod k) :
  (let let0 := mul_n6_alt; (let let1 := a_n2_alt; (let let2 := (52435875175126190479447740508185965837690552500527637822603658699938581184512 : ZMod k); (let let3 := return_n0_alt; (let let4 := (let3 * let2); (let let5 := ((let4 + let1) + let0); (let let6 := (2 : ZMod k); (let let7 := (let0 * let6); (let let8 := (let7 * let1); (let let9 := ((let8) = (let5)); (let let10 := mul_n5_alt; (let let11 := (let10 * let1); (let let12 := ((let11) = (let0)); (let let13 := mul_n4_alt; (let let14 := b_n1_alt; (let let15 := mul_n3_alt; (let let16 := (let15 * let14); (let let17 := ((let16) = (let13)); (let let18 := (let14 * let1); (let let19 := ((let18) = (let15)); (let let20 := (((let19 ∧ let17) ∧ let12) ∧ let9); (let let21 := mul_n6; (let let22 := a_n2; (let let23 := return_n0; (let let24 := (let23 * let2); (let let25 := ((let24 + let22) + let21); (let let26 := (let21 * let6); (let let27 := (let26 * let22); (let let28 := ((let27) = (let25)); (let let29 := mul_n5; (let let30 := (let29 * let22); (let let31 := ((let30) = (let21)); (let let32 := mul_n4; (let let33 := b_n1; (let let34 := mul_n3; (let let35 := (let34 * let33); (let let36 := ((let35) = (let32)); (let let37 := (let33 * let22); (let let38 := ((let37) = (let34)); (let let39 := (((let38 ∧ let36) ∧ let31) ∧ let28); (let let40 := ((let23) = (let3)); (let let41 := (¬ (let40)); (let let42 := ((let22) = (let1)); (let let43 := ((let33) = (let14)); (let let44 := (let43 ∧ let42); (let let45 := (((let44 ∧ let41) ∧ let39) ∧ let20); let45)))))))))))))))))))))))))))))))))))))))))))))) := by
  unfold k at *
  smt
