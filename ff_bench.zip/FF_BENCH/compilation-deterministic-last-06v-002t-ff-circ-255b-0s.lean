import Smt
import Smt.ZMod
import Mathlib.Data.ZMod.Basic

abbrev k := 52435875175126190479447740508185965837690552500527637822603658699938581184513

theorem compilation_deterministic_last_06v_002t_ff_circ_255b_0s [Fact k.Prime]
  (return_n3_alt : ZMod k) (a_n6_alt : ZMod k) (d_n1_alt : ZMod k) (b_n4_alt : ZMod k) (c_n2_alt : ZMod k) (f_n5_alt : ZMod k) (e_n0_alt : ZMod k) (is_zero_inv_n7_alt : ZMod k) (return_n3 : ZMod k) (a_n6 : ZMod k) (d_n1 : ZMod k) (b_n4 : ZMod k) (c_n2 : ZMod k) (f_n5 : ZMod k) (e_n0 : ZMod k) (is_zero_inv_n7 : ZMod k) :
  (let let0 := return_n3_alt; (let let1 := (1 : ZMod k); (let let2 := a_n6_alt; (let let3 := d_n1_alt; (let let4 := (52435875175126190479447740508185965837690552500527637822603658699938581184512 : ZMod k); (let let5 := b_n4_alt; (let let6 := (let5 * let4); (let let7 := c_n2_alt; (let let8 := f_n5_alt; (let let9 := e_n0_alt; (let let10 := ((((((let9 + let8) + let7) + let6) + let3) + let2) + let1); (let let11 := is_zero_inv_n7_alt; (let let12 := (let11 * let10); (let let13 := ((let12) = (let0)); (let let14 := return_n3; (let let15 := a_n6; (let let16 := d_n1; (let let17 := b_n4; (let let18 := (let17 * let4); (let let19 := c_n2; (let let20 := f_n5; (let let21 := e_n0; (let let22 := ((((((let21 + let20) + let19) + let18) + let16) + let15) + let1); (let let23 := is_zero_inv_n7; (let let24 := (let23 * let22); (let let25 := ((let24) = (let14)); (let let26 := ((let14) = (let0)); (let let27 := (¬ (let26)); (let let28 := ((let19) = (let7)); (let let29 := ((let15) = (let2)); (let let30 := ((let21) = (let9)); (let let31 := ((let20) = (let8)); (let let32 := ((let16) = (let3)); (let let33 := ((let17) = (let5)); (let let34 := (((((let33 ∧ let32) ∧ let31) ∧ let30) ∧ let29) ∧ let28); (let let35 := (((let34 ∧ let27) ∧ let25) ∧ let13); let35)))))))))))))))))))))))))))))))))))) := by
  unfold k at *
  smt
