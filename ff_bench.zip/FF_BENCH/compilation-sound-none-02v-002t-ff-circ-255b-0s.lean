import Smt
import Smt.ZMod
import Mathlib.Data.ZMod.Basic
set_option maxRecDepth 2000000000000000000000

syntax "smt_unsat" : tactic

macro_rules
  | `(tactic| smt_unsat) => `(tactic| first | smt; trace "unsat")

abbrev my_prime := 52435875175126190479447740508185965837690552500527637822603658699938581184513

theorem compilation_sound_none_02v_002t_ff_circ_255b_0s [Fact my_prime.Prime]
  (a : Bool) (b : Bool) (return_n0 : ZMod my_prime) (a_n2 : ZMod my_prime) (b_n1 : ZMod my_prime) :
  (!((let let0 := a; (let let1 := !(let0); (let let2 := b; (let let3 := (let2 && let1); (let let4 := return_n0; (let let5 := (1 : ZMod my_prime); (let let6 := (decide ((let5) = (let4))); (let let7 := (decide ((let6) = (let3))); (let let8 := (0 : ZMod my_prime); (let let9 := (decide ((let8) = (let4))); (let let10 := (let6 || let9); (let let11 := (let10 && let7); (let let12 := (52435875175126190479447740508185965837690552500527637822603658699938581184512 : ZMod my_prime); (let let13 := a_n2; (let let14 := (let13 * let12); (let let15 := (let14 + let5); (let let16 := b_n1; (let let17 := (let16 * let15); (let let18 := (decide ((let17) = (let4))); (let let19 := (if (let2) then let5 else let8); (let let20 := (decide ((let16) = (let19))); (let let21 := (if (let0) then let5 else let8); (let let22 := (decide ((let13) = (let21))); (let let23 := (let22 && let20); (let let24 := (let23 && let18); (let let25 := (!(let24) || let11); (let let26 := !(let25); let26))))))))))))))))))))))))))))) = true := by
  unfold my_prime at *
  smt_unsat
