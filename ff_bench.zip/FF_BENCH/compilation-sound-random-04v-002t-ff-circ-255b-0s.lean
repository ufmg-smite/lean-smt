import Smt
import Smt.ZMod
import Mathlib.Data.ZMod.Basic
set_option maxRecDepth 2000000000000000000000

syntax "smt_unsat" : tactic

macro_rules
  | `(tactic| smt_unsat) => `(tactic| first | smt; trace "unsat")

abbrev my_prime := 52435875175126190479447740508185965837690552500527637822603658699938581184513

theorem compilation_sound_random_04v_002t_ff_circ_255b_0s [Fact my_prime.Prime]
  (a : Bool) (d : Bool) (c : Bool) (b : Bool) (return_n2 : ZMod my_prime) (b_n3 : ZMod my_prime) (c_n1 : ZMod my_prime) (a_n4 : ZMod my_prime) (d_n0 : ZMod my_prime) (is_zero_inv_n5 : ZMod my_prime) :
  (!((let let0 := a; (let let1 := !(let0); (let let2 := d; (let let3 := c; (let let4 := b; (let let5 := (((let4 && let3) && let2) && let1); (let let6 := return_n2; (let let7 := (1 : ZMod my_prime); (let let8 := (decide ((let7) = (let6))); (let let9 := (decide ((let8) = (let5))); (let let10 := (0 : ZMod my_prime); (let let11 := (decide ((let10) = (let6))); (let let12 := (let8 || let11); (let let13 := (let12 && let9); (let let14 := (52435875175126190479447740508185965837690552500527637822603658699938581184512 : ZMod my_prime); (let let15 := (let6 * let14); (let let16 := (let15 + let7); (let let17 := (3 : ZMod my_prime); (let let18 := b_n3; (let let19 := (let18 * let14); (let let20 := c_n1; (let let21 := (let20 * let14); (let let22 := a_n4; (let let23 := d_n0; (let let24 := (let23 * let14); (let let25 := ((((let24 + let22) + let21) + let19) + let17); (let let26 := is_zero_inv_n5; (let let27 := (let26 * let25); (let let28 := (decide ((let27) = (let16))); (let let29 := (if (let0) then let7 else let10); (let let30 := (decide ((let22) = (let29))); (let let31 := (if (let3) then let7 else let10); (let let32 := (decide ((let20) = (let31))); (let let33 := (if (let2) then let7 else let10); (let let34 := (decide ((let23) = (let33))); (let let35 := (if (let4) then let7 else let10); (let let36 := (decide ((let18) = (let35))); (let let37 := (((let36 && let34) && let32) && let30); (let let38 := (let37 && let28); (let let39 := (!(let38) || let13); (let let40 := !(let39); let40))))))))))))))))))))))))))))))))))))))))))) = true := by
  unfold my_prime at *
  smt_unsat
