import Smt
import Smt.ZMod
import Mathlib.Data.ZMod.Basic

abbrev k := 52435875175126190479447740508185965837690552500527637822603658699938581184513

theorem compilation_sound_random_02v_001t_ff_zokref_255b_0s [Fact k.Prime]
  (out : ZMod k) (_2 : ZMod k) (_1 : ZMod k) (_0 : ZMod k) :
  (let let0 := b; (let let1 := a; (let let2 := (let1 ∧ let0); (let let3 := out; (let let4 := (1 : ZMod k); (let let5 := ((let4) = (let3)); (let let6 := ((let5) = (let2)); (let let7 := (0 : ZMod k); (let let8 := ((let7) = (let3)); (let let9 := (let5 ∨ let8); (let let10 := (let9 ∧ let6); (let let11 := _2; (let let12 := ((let11) = (let3)); (let let13 := _1; (let let14 := _0; (let let15 := (let14 * let13); (let let16 := ((let15) = (let11)); (let let17 := (let14 * let14); (let let18 := ((let17) = (let14)); (let let19 := ((let18 ∧ let16) ∧ let12); (let let20 := (if let0 then let4 else let7); (let let21 := ((let13) = (let20)); (let let22 := (if let1 then let4 else let7); (let let23 := ((let14) = (let22)); (let let24 := (let23 ∧ let21); (let let25 := (let24 ∧ let19); (let let26 := ((let25) → (let10)); (let let27 := (¬ (let26)); let27)))))))))))))))))))))))))))) := by
  unfold k at *
  smt
