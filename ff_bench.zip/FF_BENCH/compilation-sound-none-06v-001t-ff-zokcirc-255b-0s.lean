import Smt
import Smt.ZMod
import Mathlib.Data.ZMod.Basic
set_option maxRecDepth 2000000000000000000000

syntax "smt_unsat" : tactic

macro_rules
  | `(tactic| smt_unsat) => `(tactic| first | smt; trace "unsat")

abbrev my_prime := 52435875175126190479447740508185965837690552500527637822603658699938581184513

theorem compilation_sound_none_06v_001t_ff_zokcirc_255b_0s [Fact my_prime.Prime]
  (f : Bool) (e : Bool) (d : Bool) (c : Bool) (b : Bool) (a : Bool) (return_n3 : ZMod my_prime) (f_n5 : ZMod my_prime) (mul_n10 : ZMod my_prime) (e_n0 : ZMod my_prime) (mul_n9 : ZMod my_prime) (d_n1 : ZMod my_prime) (mul_n8 : ZMod my_prime) (c_n2 : ZMod my_prime) (mul_n7 : ZMod my_prime) (b_n4 : ZMod my_prime) (a_n6 : ZMod my_prime) :
  (!((let let0 := f; (let let1 := e; (let let2 := d; (let let3 := c; (let let4 := b; (let let5 := a; (let let6 := (((((let5 && let4) && let3) && let2) && let1) && let0); (let let7 := return_n3; (let let8 := (1 : ZMod my_prime); (let let9 := (decide ((let8) = (let7))); (let let10 := (decide ((let9) = (let6))); (let let11 := (0 : ZMod my_prime); (let let12 := (decide ((let11) = (let7))); (let let13 := (let9 || let12); (let let14 := (let13 && let10); (let let15 := f_n5; (let let16 := mul_n10; (let let17 := (let16 * let15); (let let18 := (decide ((let17) = (let7))); (let let19 := e_n0; (let let20 := mul_n9; (let let21 := (let20 * let19); (let let22 := (decide ((let21) = (let16))); (let let23 := d_n1; (let let24 := mul_n8; (let let25 := (let24 * let23); (let let26 := (decide ((let25) = (let20))); (let let27 := c_n2; (let let28 := mul_n7; (let let29 := (let28 * let27); (let let30 := (decide ((let29) = (let24))); (let let31 := b_n4; (let let32 := a_n6; (let let33 := (let32 * let31); (let let34 := (decide ((let33) = (let28))); (let let35 := ((((let34 && let30) && let26) && let22) && let18); (let let36 := (if (let2) then let8 else let11); (let let37 := (decide ((let23) = (let36))); (let let38 := (if (let0) then let8 else let11); (let let39 := (decide ((let15) = (let38))); (let let40 := (if (let1) then let8 else let11); (let let41 := (decide ((let19) = (let40))); (let let42 := (if (let5) then let8 else let11); (let let43 := (decide ((let32) = (let42))); (let let44 := (if (let4) then let8 else let11); (let let45 := (decide ((let31) = (let44))); (let let46 := (if (let3) then let8 else let11); (let let47 := (decide ((let27) = (let46))); (let let48 := (((((let47 && let45) && let43) && let41) && let39) && let37); (let let49 := (let48 && let35); (let let50 := (!(let49) || let14); (let let51 := !(let50); let51)))))))))))))))))))))))))))))))))))))))))))))))))))))) = true := by
  unfold my_prime at *
  smt_unsat
