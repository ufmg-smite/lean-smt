import Smt
import Smt.ZMod
import Mathlib.Data.ZMod.Basic

abbrev k := 52435875175126190479447740508185965837690552500527637822603658699938581184513

theorem compilation_deterministic_none_06v_001t_ff_circ_255b_0s [Fact k.Prime]
  (a_n6_alt : ZMod k) (d_n1_alt : ZMod k) (f_n4_alt : ZMod k) (c_n2_alt : ZMod k) (b_n5_alt : ZMod k) (e_n0_alt : ZMod k) (return_n3_alt : ZMod k) (is_zero_inv_n7_alt : ZMod k) (a_n6 : ZMod k) (d_n1 : ZMod k) (f_n4 : ZMod k) (c_n2 : ZMod k) (b_n5 : ZMod k) (e_n0 : ZMod k) (return_n3 : ZMod k) (is_zero_inv_n7 : ZMod k) :
  (let let0 := (0 : ZMod k); (let let1 := a_n6_alt; (let let2 := d_n1_alt; (let let3 := f_n4_alt; (let let4 := c_n2_alt; (let let5 := b_n5_alt; (let let6 := e_n0_alt; (let let7 := (((((let6 + let5) + let4) + let3) + let2) + let1); (let let8 := (1 : ZMod k); (let let9 := (52435875175126190479447740508185965837690552500527637822603658699938581184512 : ZMod k); (let let10 := return_n3_alt; (let let11 := (let10 * let9); (let let12 := (let11 + let8); (let let13 := (let12 * let7); (let let14 := ((let13) = (let0)); (let let15 := is_zero_inv_n7_alt; (let let16 := (let15 * let7); (let let17 := ((let16) = (let10)); (let let18 := (let17 ∧ let14); (let let19 := a_n6; (let let20 := d_n1; (let let21 := f_n4; (let let22 := c_n2; (let let23 := b_n5; (let let24 := e_n0; (let let25 := (((((let24 + let23) + let22) + let21) + let20) + let19); (let let26 := return_n3; (let let27 := (let26 * let9); (let let28 := (let27 + let8); (let let29 := (let28 * let25); (let let30 := ((let29) = (let0)); (let let31 := is_zero_inv_n7; (let let32 := (let31 * let25); (let let33 := ((let32) = (let26)); (let let34 := (let33 ∧ let30); (let let35 := ((let26) = (let10)); (let let36 := (¬ (let35)); (let let37 := ((let21) = (let3)); (let let38 := ((let22) = (let4)); (let let39 := ((let23) = (let5)); (let let40 := ((let24) = (let6)); (let let41 := ((let20) = (let2)); (let let42 := ((let19) = (let1)); (let let43 := (((((let42 ∧ let41) ∧ let40) ∧ let39) ∧ let38) ∧ let37); (let let44 := (((let43 ∧ let36) ∧ let34) ∧ let18); let44))))))))))))))))))))))))))))))))))))))))))))) := by
  unfold k at *
  smt
