import Smt
import Smt.ZMod
import Mathlib.Data.ZMod.Basic
set_option maxRecDepth 2000000000000000000000

syntax "smt_unsat" : tactic

macro_rules
  | `(tactic| smt_unsat) => `(tactic| first | smt; trace "unsat")

abbrev my_prime := 37

theorem compilation_deterministic_none_02v_004t_ff_zokcirc_6b_0s [Fact my_prime.Prime]
  (mul_n6_alt : ZMod my_prime) (a_n2_alt : ZMod my_prime) (return_n0_alt : ZMod my_prime) (mul_n5_alt : ZMod my_prime) (mul_n4_alt : ZMod my_prime) (b_n1_alt : ZMod my_prime) (mul_n3_alt : ZMod my_prime) (mul_n6 : ZMod my_prime) (a_n2 : ZMod my_prime) (return_n0 : ZMod my_prime) (mul_n5 : ZMod my_prime) (mul_n4 : ZMod my_prime) (b_n1 : ZMod my_prime) (mul_n3 : ZMod my_prime) :
  (!((let let0 := mul_n6_alt; (let let1 := a_n2_alt; (let let2 := (36 : ZMod my_prime); (let let3 := return_n0_alt; (let let4 := (let3 * let2); (let let5 := ((let4 + let1) + let0); (let let6 := (2 : ZMod my_prime); (let let7 := (let0 * let6); (let let8 := (let7 * let1); (let let9 := (decide ((let8) = (let5))); (let let10 := mul_n5_alt; (let let11 := (let10 * let1); (let let12 := (decide ((let11) = (let0))); (let let13 := mul_n4_alt; (let let14 := (let13 * let1); (let let15 := (decide ((let14) = (let10))); (let let16 := b_n1_alt; (let let17 := mul_n3_alt; (let let18 := (let17 * let16); (let let19 := (decide ((let18) = (let13))); (let let20 := (let16 * let1); (let let21 := (decide ((let20) = (let17))); (let let22 := ((((let21 && let19) && let15) && let12) && let9); (let let23 := mul_n6; (let let24 := a_n2; (let let25 := return_n0; (let let26 := (let25 * let2); (let let27 := ((let26 + let24) + let23); (let let28 := (let23 * let6); (let let29 := (let28 * let24); (let let30 := (decide ((let29) = (let27))); (let let31 := mul_n5; (let let32 := (let31 * let24); (let let33 := (decide ((let32) = (let23))); (let let34 := mul_n4; (let let35 := (let34 * let24); (let let36 := (decide ((let35) = (let31))); (let let37 := b_n1; (let let38 := mul_n3; (let let39 := (let38 * let37); (let let40 := (decide ((let39) = (let34))); (let let41 := (let37 * let24); (let let42 := (decide ((let41) = (let38))); (let let43 := ((((let42 && let40) && let36) && let33) && let30); (let let44 := (decide ((let25) = (let3))); (let let45 := !(let44); (let let46 := (decide ((let37) = (let16))); (let let47 := (decide ((let24) = (let1))); (let let48 := (let47 && let46); (let let49 := (((let48 && let45) && let43) && let22); let49)))))))))))))))))))))))))))))))))))))))))))))))))))) = true := by
  unfold my_prime at *
  smt_unsat
