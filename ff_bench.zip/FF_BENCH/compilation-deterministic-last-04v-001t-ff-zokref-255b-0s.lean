import Smt
import Smt.ZMod
import Mathlib.Data.ZMod.Basic
set_option maxRecDepth 2000000000000000000000

syntax "smt_unsat" : tactic

macro_rules
  | `(tactic| smt_unsat) => `(tactic| first | smt; trace "unsat")

abbrev my_prime := 52435875175126190479447740508185965837690552500527637822603658699938581184513

theorem compilation_deterministic_last_04v_001t_ff_zokref_255b_0s [Fact my_prime.Prime]
  (_6_alt : ZMod my_prime) (_3_alt : ZMod my_prime) (_5_alt : ZMod my_prime) (_2_alt : ZMod my_prime) (_4_alt : ZMod my_prime) (_1_alt : ZMod my_prime) (_0_alt : ZMod my_prime) (_6 : ZMod my_prime) (_3 : ZMod my_prime) (_5 : ZMod my_prime) (_2 : ZMod my_prime) (_4 : ZMod my_prime) (_1 : ZMod my_prime) (_0 : ZMod my_prime) (out_alt : ZMod my_prime) (out : ZMod my_prime) :
  (!((let let0 := _6_alt; (let let1 := _3_alt; (let let2 := _5_alt; (let let3 := (let2 * let1); (let let4 := (decide ((let3) = (let0))); (let let5 := _2_alt; (let let6 := _4_alt; (let let7 := (let6 * let5); (let let8 := (decide ((let7) = (let2))); (let let9 := _1_alt; (let let10 := _0_alt; (let let11 := (let10 * let9); (let let12 := (decide ((let11) = (let6))); (let let13 := (let1 * let1); (let let14 := (decide ((let13) = (let1))); (let let15 := (let5 * let5); (let let16 := (decide ((let15) = (let5))); (let let17 := (let9 * let9); (let let18 := (decide ((let17) = (let9))); (let let19 := (let10 * let10); (let let20 := (decide ((let19) = (let10))); (let let21 := ((((((let20 && let18) && let16) && let14) && let12) && let8) && let4); (let let22 := _6; (let let23 := _3; (let let24 := _5; (let let25 := (let24 * let23); (let let26 := (decide ((let25) = (let22))); (let let27 := _2; (let let28 := _4; (let let29 := (let28 * let27); (let let30 := (decide ((let29) = (let24))); (let let31 := _1; (let let32 := _0; (let let33 := (let32 * let31); (let let34 := (decide ((let33) = (let28))); (let let35 := (let23 * let23); (let let36 := (decide ((let35) = (let23))); (let let37 := (let27 * let27); (let let38 := (decide ((let37) = (let27))); (let let39 := (let31 * let31); (let let40 := (decide ((let39) = (let31))); (let let41 := (let32 * let32); (let let42 := (decide ((let41) = (let32))); (let let43 := ((((((let42 && let40) && let38) && let36) && let34) && let30) && let26); (let let44 := out_alt; (let let45 := out; (let let46 := (decide ((let45) = (let44))); (let let47 := !(let46); (let let48 := (decide ((let27) = (let5))); (let let49 := (decide ((let23) = (let1))); (let let50 := (decide ((let31) = (let9))); (let let51 := (decide ((let32) = (let10))); (let let52 := (((let51 && let50) && let49) && let48); (let let53 := (((let52 && let47) && let43) && let21); let53)))))))))))))))))))))))))))))))))))))))))))))))))))))))) = true := by
  unfold my_prime at *
  smt_unsat
