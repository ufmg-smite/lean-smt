import Smt
import Smt.ZMod
import Mathlib.Data.ZMod.Basic

abbrev k := 52435875175126190479447740508185965837690552500527637822603658699938581184513

theorem compilation_deterministic_random_02v_002t_ff_zokcirc_255b_0s [Fact k.Prime]
  (mul_n3_alt : ZMod k) (b_n1_alt : ZMod k) (a_n2_alt : ZMod k) (mul_n3 : ZMod k) (b_n1 : ZMod k) (a_n2 : ZMod k) (return_n0_alt : ZMod k) (return_n0 : ZMod k) :
  (let let0 := mul_n3_alt; (let let1 := (1 : ZMod k); (let let2 := (52435875175126190479447740508185965837690552500527637822603658699938581184512 : ZMod k); (let let3 := b_n1_alt; (let let4 := (let3 * let2); (let let5 := (let4 + let1); (let let6 := a_n2_alt; (let let7 := (let6 * let2); (let let8 := (let7 + let1); (let let9 := (let8 * let5); (let let10 := ((let9) = (let0)); (let let11 := mul_n3; (let let12 := b_n1; (let let13 := (let12 * let2); (let let14 := (let13 + let1); (let let15 := a_n2; (let let16 := (let15 * let2); (let let17 := (let16 + let1); (let let18 := (let17 * let14); (let let19 := ((let18) = (let11)); (let let20 := return_n0_alt; (let let21 := return_n0; (let let22 := ((let21) = (let20)); (let let23 := (¬ (let22)); (let let24 := ((let15) = (let6)); (let let25 := ((let12) = (let3)); (let let26 := (let25 ∧ let24); (let let27 := (((let26 ∧ let23) ∧ let19) ∧ let10); let27)))))))))))))))))))))))))))) := by
  unfold k at *
  smt
