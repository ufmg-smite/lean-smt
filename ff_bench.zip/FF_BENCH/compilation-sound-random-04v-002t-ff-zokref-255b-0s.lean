import Smt
import Smt.ZMod
import Mathlib.Data.ZMod.Basic

abbrev k := 52435875175126190479447740508185965837690552500527637822603658699938581184513

theorem compilation_sound_random_04v_002t_ff_zokref_255b_0s [Fact k.Prime]
  (out : ZMod k) (_7 : ZMod k) (_0 : ZMod k) (_6 : ZMod k) (_5 : ZMod k) (_2 : ZMod k) (_1 : ZMod k) (_3 : ZMod k) :
  (let let0 := a; (let let1 := (¬ (let0)); (let let2 := d; (let let3 := c; (let let4 := b; (let let5 := (((let4 ∧ let3) ∧ let2) ∧ let1); (let let6 := out; (let let7 := (1 : ZMod k); (let let8 := ((let7) = (let6)); (let let9 := ((let8) = (let5)); (let let10 := (0 : ZMod k); (let let11 := ((let10) = (let6)); (let let12 := (let8 ∨ let11); (let let13 := (let12 ∧ let9); (let let14 := _7; (let let15 := ((let14) = (let6)); (let let16 := (52435875175126190479447740508185965837690552500527637822603658699938581184512 : ZMod k); (let let17 := _0; (let let18 := (let17 * let16); (let let19 := (let18 + let7); (let let20 := _6; (let let21 := (let20 * let19); (let let22 := ((let21) = (let14)); (let let23 := _5; (let let24 := _2; (let let25 := _1; (let let26 := (let25 * let24); (let let27 := ((let26) = (let23)); (let let28 := _3; (let let29 := (let28 * let28); (let let30 := ((let29) = (let28)); (let let31 := (let24 * let24); (let let32 := ((let31) = (let24)); (let let33 := (let25 * let25); (let let34 := ((let33) = (let25)); (let let35 := (let17 * let17); (let let36 := ((let35) = (let17)); (let let37 := ((((((let36 ∧ let34) ∧ let32) ∧ let30) ∧ let27) ∧ let22) ∧ let15); (let let38 := (if let4 then let7 else let10); (let let39 := ((let25) = (let38)); (let let40 := (if let0 then let7 else let10); (let let41 := ((let17) = (let40)); (let let42 := (if let2 then let7 else let10); (let let43 := ((let28) = (let42)); (let let44 := (if let3 then let7 else let10); (let let45 := ((let24) = (let44)); (let let46 := (((let45 ∧ let43) ∧ let41) ∧ let39); (let let47 := (let46 ∧ let37); (let let48 := ((let47) → (let13)); (let let49 := (¬ (let48)); let49)))))))))))))))))))))))))))))))))))))))))))))))))) := by
  unfold k at *
  smt
