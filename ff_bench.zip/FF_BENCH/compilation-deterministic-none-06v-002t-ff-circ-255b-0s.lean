import Smt
import Smt.ZMod
import Mathlib.Data.ZMod.Basic
set_option maxRecDepth 2000000000000000000000

syntax "smt_unsat" : tactic

macro_rules
  | `(tactic| smt_unsat) => `(tactic| first | smt; trace "unsat")

abbrev my_prime := 52435875175126190479447740508185965837690552500527637822603658699938581184513

theorem compilation_deterministic_none_06v_002t_ff_circ_255b_0s [Fact my_prime.Prime]
  (a_n6_alt : ZMod my_prime) (d_n1_alt : ZMod my_prime) (b_n4_alt : ZMod my_prime) (c_n2_alt : ZMod my_prime) (f_n5_alt : ZMod my_prime) (e_n0_alt : ZMod my_prime) (return_n3_alt : ZMod my_prime) (is_zero_inv_n7_alt : ZMod my_prime) (a_n6 : ZMod my_prime) (d_n1 : ZMod my_prime) (b_n4 : ZMod my_prime) (c_n2 : ZMod my_prime) (f_n5 : ZMod my_prime) (e_n0 : ZMod my_prime) (return_n3 : ZMod my_prime) (is_zero_inv_n7 : ZMod my_prime) :
  (!((let let0 := (0 : ZMod my_prime); (let let1 := (1 : ZMod my_prime); (let let2 := a_n6_alt; (let let3 := d_n1_alt; (let let4 := (52435875175126190479447740508185965837690552500527637822603658699938581184512 : ZMod my_prime); (let let5 := b_n4_alt; (let let6 := (let5 * let4); (let let7 := c_n2_alt; (let let8 := f_n5_alt; (let let9 := e_n0_alt; (let let10 := ((((((let9 + let8) + let7) + let6) + let3) + let2) + let1); (let let11 := return_n3_alt; (let let12 := (let11 * let4); (let let13 := (let12 + let1); (let let14 := (let13 * let10); (let let15 := (decide ((let14) = (let0))); (let let16 := is_zero_inv_n7_alt; (let let17 := (let16 * let10); (let let18 := (decide ((let17) = (let11))); (let let19 := (let18 && let15); (let let20 := a_n6; (let let21 := d_n1; (let let22 := b_n4; (let let23 := (let22 * let4); (let let24 := c_n2; (let let25 := f_n5; (let let26 := e_n0; (let let27 := ((((((let26 + let25) + let24) + let23) + let21) + let20) + let1); (let let28 := return_n3; (let let29 := (let28 * let4); (let let30 := (let29 + let1); (let let31 := (let30 * let27); (let let32 := (decide ((let31) = (let0))); (let let33 := is_zero_inv_n7; (let let34 := (let33 * let27); (let let35 := (decide ((let34) = (let28))); (let let36 := (let35 && let32); (let let37 := (decide ((let28) = (let11))); (let let38 := !(let37); (let let39 := (decide ((let21) = (let3))); (let let40 := (decide ((let22) = (let5))); (let let41 := (decide ((let25) = (let8))); (let let42 := (decide ((let26) = (let9))); (let let43 := (decide ((let20) = (let2))); (let let44 := (decide ((let24) = (let7))); (let let45 := (((((let44 && let43) && let42) && let41) && let40) && let39); (let let46 := (((let45 && let38) && let36) && let19); let46))))))))))))))))))))))))))))))))))))))))))))))))) = true := by
  unfold my_prime at *
  smt_unsat
