import Smt
import Smt.ZMod
import Mathlib.Data.ZMod.Basic
set_option maxRecDepth 2000000000000000000000

syntax "smt_unsat" : tactic

macro_rules
  | `(tactic| smt_unsat) => `(tactic| first | smt; trace "unsat")

abbrev my_prime := 52435875175126190479447740508185965837690552500527637822603658699938581184513

theorem compilation_deterministic_last_12v_001t_ff_circ_255b_0s [Fact my_prime.Prime]
  (return_n9_alt : ZMod my_prime) (k_n3_alt : ZMod my_prime) (d_n6_alt : ZMod my_prime) (a_n12_alt : ZMod my_prime) (f_n2_alt : ZMod my_prime) (j_n5_alt : ZMod my_prime) (c_n8_alt : ZMod my_prime) (h_n11_alt : ZMod my_prime) (l_n1_alt : ZMod my_prime) (e_n4_alt : ZMod my_prime) (i_n7_alt : ZMod my_prime) (b_n10_alt : ZMod my_prime) (g_n0_alt : ZMod my_prime) (is_zero_inv_n13_alt : ZMod my_prime) (return_n9 : ZMod my_prime) (k_n3 : ZMod my_prime) (d_n6 : ZMod my_prime) (a_n12 : ZMod my_prime) (f_n2 : ZMod my_prime) (j_n5 : ZMod my_prime) (c_n8 : ZMod my_prime) (h_n11 : ZMod my_prime) (l_n1 : ZMod my_prime) (e_n4 : ZMod my_prime) (i_n7 : ZMod my_prime) (b_n10 : ZMod my_prime) (g_n0 : ZMod my_prime) (is_zero_inv_n13 : ZMod my_prime) :
  (!((let let0 := return_n9_alt; (let let1 := k_n3_alt; (let let2 := d_n6_alt; (let let3 := a_n12_alt; (let let4 := f_n2_alt; (let let5 := j_n5_alt; (let let6 := c_n8_alt; (let let7 := h_n11_alt; (let let8 := l_n1_alt; (let let9 := e_n4_alt; (let let10 := i_n7_alt; (let let11 := b_n10_alt; (let let12 := g_n0_alt; (let let13 := (((((((((((let12 + let11) + let10) + let9) + let8) + let7) + let6) + let5) + let4) + let3) + let2) + let1); (let let14 := is_zero_inv_n13_alt; (let let15 := (let14 * let13); (let let16 := (decide ((let15) = (let0))); (let let17 := return_n9; (let let18 := k_n3; (let let19 := d_n6; (let let20 := a_n12; (let let21 := f_n2; (let let22 := j_n5; (let let23 := c_n8; (let let24 := h_n11; (let let25 := l_n1; (let let26 := e_n4; (let let27 := i_n7; (let let28 := b_n10; (let let29 := g_n0; (let let30 := (((((((((((let29 + let28) + let27) + let26) + let25) + let24) + let23) + let22) + let21) + let20) + let19) + let18); (let let31 := is_zero_inv_n13; (let let32 := (let31 * let30); (let let33 := (decide ((let32) = (let17))); (let let34 := (decide ((let17) = (let0))); (let let35 := !(let34); (let let36 := (decide ((let21) = (let4))); (let let37 := (decide ((let18) = (let1))); (let let38 := (decide ((let22) = (let5))); (let let39 := (decide ((let25) = (let8))); (let let40 := (decide ((let20) = (let3))); (let let41 := (decide ((let23) = (let6))); (let let42 := (decide ((let29) = (let12))); (let let43 := (decide ((let26) = (let9))); (let let44 := (decide ((let27) = (let10))); (let let45 := (decide ((let24) = (let7))); (let let46 := (decide ((let28) = (let11))); (let let47 := (decide ((let19) = (let2))); (let let48 := (((((((((((let47 && let46) && let45) && let44) && let43) && let42) && let41) && let40) && let39) && let38) && let37) && let36); (let let49 := (((let48 && let35) && let33) && let16); let49)))))))))))))))))))))))))))))))))))))))))))))))))))) = true := by
  unfold my_prime at *
  smt_unsat
