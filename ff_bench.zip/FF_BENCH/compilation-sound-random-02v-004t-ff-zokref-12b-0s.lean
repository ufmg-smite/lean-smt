import Smt
import Smt.ZMod
import Mathlib.Data.ZMod.Basic
set_option maxRecDepth 2000000000000000000000

syntax "smt_unsat" : tactic

macro_rules
  | `(tactic| smt_unsat) => `(tactic| first | smt; trace "unsat")

abbrev my_prime := 2053

theorem compilation_sound_random_02v_004t_ff_zokref_12b_0s [Fact my_prime.Prime]
  (a : Bool) (b : Bool) (out : ZMod my_prime) (_10 : ZMod my_prime) (_2 : ZMod my_prime) (_8 : ZMod my_prime) (_7 : ZMod my_prime) (_0 : ZMod my_prime) (_1 : ZMod my_prime) :
  (!((let let0 := a; (let let1 := b; (let let2 := (!(let1) || let0); (let let3 := !(let2); (let let4 := (if (let2) then let1 else let0); (let let5 := (let4 && let3); (let let6 := out; (let let7 := (1 : ZMod my_prime); (let let8 := (decide ((let7) = (let6))); (let let9 := (decide ((let8) = (let5))); (let let10 := (0 : ZMod my_prime); (let let11 := (decide ((let10) = (let6))); (let let12 := (let8 || let11); (let let13 := (let12 && let9); (let let14 := _10; (let let15 := (decide ((let14) = (let6))); (let let16 := (2052 : ZMod my_prime); (let let17 := _2; (let let18 := (let17 * let16); (let let19 := (let18 + let7); (let let20 := _8; (let let21 := _7; (let let22 := (let21 + let20); (let let23 := (let22 * let19); (let let24 := (decide ((let23) = (let14))); (let let25 := _0; (let let26 := (let19 * let25); (let let27 := (decide ((let26) = (let20))); (let let28 := _1; (let let29 := (let28 * let16); (let let30 := (((let25 + let29) + let18) + let7); (let let31 := (let29 + let7); (let let32 := (let31 * let25); (let let33 := (decide ((let32) = (let30))); (let let34 := (let28 * let28); (let let35 := (decide ((let34) = (let28))); (let let36 := (let25 * let25); (let let37 := (decide ((let36) = (let25))); (let let38 := (((((let37 && let35) && let33) && let27) && let24) && let15); (let let39 := (if (let0) then let7 else let10); (let let40 := (decide ((let25) = (let39))); (let let41 := (if (let1) then let7 else let10); (let let42 := (decide ((let28) = (let41))); (let let43 := (let42 && let40); (let let44 := (let43 && let38); (let let45 := (!(let44) || let13); (let let46 := !(let45); let46))))))))))))))))))))))))))))))))))))))))))))))))) = true := by
  unfold my_prime at *
  smt_unsat
