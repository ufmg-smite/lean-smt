import Smt
import Smt.ZMod
import Mathlib.Data.ZMod.Basic
set_option maxRecDepth 2000000000000000000000

syntax "smt_unsat" : tactic

macro_rules
  | `(tactic| smt_unsat) => `(tactic| first | smt; trace "unsat")

abbrev my_prime := 52435875175126190479447740508185965837690552500527637822603658699938581184513

theorem compilation_sound_last_02v_001t_ff_zokref_255b_0s [Fact my_prime.Prime]
  (b : Bool) (a : Bool) (out : ZMod my_prime) (_2 : ZMod my_prime) (_1 : ZMod my_prime) (_0 : ZMod my_prime) :
  (!((let let0 := b; (let let1 := a; (let let2 := (let1 && let0); (let let3 := out; (let let4 := (1 : ZMod my_prime); (let let5 := (decide ((let4) = (let3))); (let let6 := (decide ((let5) = (let2))); (let let7 := (0 : ZMod my_prime); (let let8 := (decide ((let7) = (let3))); (let let9 := (let5 || let8); (let let10 := (let9 && let6); (let let11 := _2; (let let12 := _1; (let let13 := _0; (let let14 := (let13 * let12); (let let15 := (decide ((let14) = (let11))); (let let16 := (let12 * let12); (let let17 := (decide ((let16) = (let12))); (let let18 := (let13 * let13); (let let19 := (decide ((let18) = (let13))); (let let20 := ((let19 && let17) && let15); (let let21 := (if (let0) then let4 else let7); (let let22 := (decide ((let12) = (let21))); (let let23 := (if (let1) then let4 else let7); (let let24 := (decide ((let13) = (let23))); (let let25 := (let24 && let22); (let let26 := (let25 && let20); (let let27 := (!(let26) || let10); (let let28 := !(let27); let28))))))))))))))))))))))))))))))) = true := by
  unfold my_prime at *
  smt_unsat
