import Smt
import Smt.ZMod
import Mathlib.Data.ZMod.Basic
set_option maxRecDepth 2000000000000000000000

syntax "smt_unsat" : tactic

macro_rules
  | `(tactic| smt_unsat) => `(tactic| first | smt; trace "unsat")

abbrev my_prime := 52435875175126190479447740508185965837690552500527637822603658699938581184513

theorem compilation_deterministic_random_06v_001t_ff_circ_255b_0s [Fact my_prime.Prime]
  (return_n3_alt : ZMod my_prime) (a_n6_alt : ZMod my_prime) (d_n1_alt : ZMod my_prime) (f_n4_alt : ZMod my_prime) (c_n2_alt : ZMod my_prime) (b_n5_alt : ZMod my_prime) (e_n0_alt : ZMod my_prime) (is_zero_inv_n7_alt : ZMod my_prime) (return_n3 : ZMod my_prime) (a_n6 : ZMod my_prime) (d_n1 : ZMod my_prime) (f_n4 : ZMod my_prime) (c_n2 : ZMod my_prime) (b_n5 : ZMod my_prime) (e_n0 : ZMod my_prime) (is_zero_inv_n7 : ZMod my_prime) :
  (!((let let0 := return_n3_alt; (let let1 := a_n6_alt; (let let2 := d_n1_alt; (let let3 := f_n4_alt; (let let4 := c_n2_alt; (let let5 := b_n5_alt; (let let6 := e_n0_alt; (let let7 := (((((let6 + let5) + let4) + let3) + let2) + let1); (let let8 := is_zero_inv_n7_alt; (let let9 := (let8 * let7); (let let10 := (decide ((let9) = (let0))); (let let11 := return_n3; (let let12 := a_n6; (let let13 := d_n1; (let let14 := f_n4; (let let15 := c_n2; (let let16 := b_n5; (let let17 := e_n0; (let let18 := (((((let17 + let16) + let15) + let14) + let13) + let12); (let let19 := is_zero_inv_n7; (let let20 := (let19 * let18); (let let21 := (decide ((let20) = (let11))); (let let22 := (decide ((let11) = (let0))); (let let23 := !(let22); (let let24 := (decide ((let16) = (let5))); (let let25 := (decide ((let15) = (let4))); (let let26 := (decide ((let17) = (let6))); (let let27 := (decide ((let14) = (let3))); (let let28 := (decide ((let13) = (let2))); (let let29 := (decide ((let12) = (let1))); (let let30 := (((((let29 && let28) && let27) && let26) && let25) && let24); (let let31 := (((let30 && let23) && let21) && let10); let31)))))))))))))))))))))))))))))))))) = true := by
  unfold my_prime at *
  smt_unsat
