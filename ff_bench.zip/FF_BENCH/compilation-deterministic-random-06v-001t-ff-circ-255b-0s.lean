import Smt
import Smt.ZMod
import Mathlib.Data.ZMod.Basic

abbrev k := 52435875175126190479447740508185965837690552500527637822603658699938581184513

theorem compilation_deterministic_random_06v_001t_ff_circ_255b_0s [Fact k.Prime]
  (return_n3_alt : ZMod k) (a_n6_alt : ZMod k) (d_n1_alt : ZMod k) (f_n4_alt : ZMod k) (c_n2_alt : ZMod k) (b_n5_alt : ZMod k) (e_n0_alt : ZMod k) (is_zero_inv_n7_alt : ZMod k) (return_n3 : ZMod k) (a_n6 : ZMod k) (d_n1 : ZMod k) (f_n4 : ZMod k) (c_n2 : ZMod k) (b_n5 : ZMod k) (e_n0 : ZMod k) (is_zero_inv_n7 : ZMod k) :
  (let let0 := return_n3_alt; (let let1 := a_n6_alt; (let let2 := d_n1_alt; (let let3 := f_n4_alt; (let let4 := c_n2_alt; (let let5 := b_n5_alt; (let let6 := e_n0_alt; (let let7 := (((((let6 + let5) + let4) + let3) + let2) + let1); (let let8 := is_zero_inv_n7_alt; (let let9 := (let8 * let7); (let let10 := ((let9) = (let0)); (let let11 := return_n3; (let let12 := a_n6; (let let13 := d_n1; (let let14 := f_n4; (let let15 := c_n2; (let let16 := b_n5; (let let17 := e_n0; (let let18 := (((((let17 + let16) + let15) + let14) + let13) + let12); (let let19 := is_zero_inv_n7; (let let20 := (let19 * let18); (let let21 := ((let20) = (let11)); (let let22 := ((let11) = (let0)); (let let23 := (¬ (let22)); (let let24 := ((let16) = (let5)); (let let25 := ((let15) = (let4)); (let let26 := ((let17) = (let6)); (let let27 := ((let14) = (let3)); (let let28 := ((let13) = (let2)); (let let29 := ((let12) = (let1)); (let let30 := (((((let29 ∧ let28) ∧ let27) ∧ let26) ∧ let25) ∧ let24); (let let31 := (((let30 ∧ let23) ∧ let21) ∧ let10); let31)))))))))))))))))))))))))))))))) := by
  unfold k at *
  smt
