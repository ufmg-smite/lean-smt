import Smt
import Smt.ZMod
import Mathlib.Data.ZMod.Basic
set_option maxRecDepth 2000000000000000000000

syntax "smt_unsat" : tactic

macro_rules
  | `(tactic| smt_unsat) => `(tactic| first | smt; trace "unsat")

abbrev my_prime := 52435875175126190479447740508185965837690552500527637822603658699938581184513

theorem compilation_deterministic_random_02v_004t_ff_circ_255b_0s [Fact my_prime.Prime]
  (a_n2_alt : ZMod my_prime) (is_zero_n4_alt : ZMod my_prime) (return_n0_alt : ZMod my_prime) (b_n1_alt : ZMod my_prime) (is_zero_inv_n3_alt : ZMod my_prime) (a_n2 : ZMod my_prime) (is_zero_n4 : ZMod my_prime) (return_n0 : ZMod my_prime) (b_n1 : ZMod my_prime) (is_zero_inv_n3 : ZMod my_prime) :
  (!((let let0 := a_n2_alt; (let let1 := is_zero_n4_alt; (let let2 := (52435875175126190479447740508185965837690552500527637822603658699938581184512 : ZMod my_prime); (let let3 := return_n0_alt; (let let4 := (let3 * let2); (let let5 := ((let4 + let1) + let0); (let let6 := (2 : ZMod my_prime); (let let7 := (let1 * let6); (let let8 := (let7 * let0); (let let9 := (decide ((let8) = (let5))); (let let10 := (1 : ZMod my_prime); (let let11 := (let1 * let2); (let let12 := (let11 + let10); (let let13 := (5 : ZMod my_prime); (let let14 := (52435875175126190479447740508185965837690552500527637822603658699938581184510 : ZMod my_prime); (let let15 := (let0 * let14); (let let16 := (52435875175126190479447740508185965837690552500527637822603658699938581184511 : ZMod my_prime); (let let17 := b_n1_alt; (let let18 := (let17 * let16); (let let19 := ((let18 + let15) + let13); (let let20 := is_zero_inv_n3_alt; (let let21 := (let20 * let19); (let let22 := (decide ((let21) = (let12))); (let let23 := (let22 && let9); (let let24 := a_n2; (let let25 := is_zero_n4; (let let26 := return_n0; (let let27 := (let26 * let2); (let let28 := ((let27 + let25) + let24); (let let29 := (let25 * let6); (let let30 := (let29 * let24); (let let31 := (decide ((let30) = (let28))); (let let32 := (let25 * let2); (let let33 := (let32 + let10); (let let34 := (let24 * let14); (let let35 := b_n1; (let let36 := (let35 * let16); (let let37 := ((let36 + let34) + let13); (let let38 := is_zero_inv_n3; (let let39 := (let38 * let37); (let let40 := (decide ((let39) = (let33))); (let let41 := (let40 && let31); (let let42 := (decide ((let26) = (let3))); (let let43 := !(let42); (let let44 := (decide ((let35) = (let17))); (let let45 := (decide ((let24) = (let0))); (let let46 := (let45 && let44); (let let47 := (((let46 && let43) && let41) && let23); let47)))))))))))))))))))))))))))))))))))))))))))))))))) = true := by
  unfold my_prime at *
  smt_unsat
